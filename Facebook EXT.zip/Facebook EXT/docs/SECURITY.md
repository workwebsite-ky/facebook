# Security model

## Threat model

LeadLoom is a single-user productivity extension. The realistic threats are:

| Threat | Mitigation |
|---|---|
| Malicious page steals API key via DOM | Keys live in `chrome.storage.local`, read only by the service worker. Content scripts never see them. |
| Malicious page impersonates LeadLoom UI | We never inject UI inside Facebook except the floating Save button; the dashboard runs on `chrome-extension://`. |
| Supply-chain attack via a dep with remote code | MV3 forbids remote code; CSP locks `script-src` to `'self'`. Run `npm audit` in CI. |
| User pastes a key into the wrong field | Inputs are `type="password"`; keys are scoped per provider. |
| Lost device → leaked DB | Chrome's profile encryption covers IndexedDB; users should enable OS disk encryption. |

## Permissions, justified

| Permission | Why |
|---|---|
| `storage` | Settings + lightweight flags in `chrome.storage.local` |
| `alarms` | Scheduled Meta sync |
| `notifications` | Hot-lead desktop alerts |
| `tabs` | Open the dashboard / Messenger in a new tab |
| `scripting` | Reserved for future programmatic content-script injection (not currently used) |
| `contextMenus` | Reserved for "Save as lead" right-click action (roadmap) |
| `identity` | Optional: future OAuth flow for Meta/Anthropic logins |
| `host_permissions: graph.facebook.com, api.anthropic.com, api.openai.com` | Only the three APIs we actually call. **No `<all_urls>`.** |
| `content_scripts: facebook.com` | Required to inject the manual save button |

If you want to harden further, remove `scripting`, `contextMenus`, and `identity` from `manifest.json` until you actually use them.

## Content Security Policy

```
script-src 'self'; object-src 'self'; connect-src 'self' https://graph.facebook.com https://api.anthropic.com https://api.openai.com;
```

This blocks:
- Inline scripts (`<script>alert(1)</script>` in any extension HTML)
- Remote scripts (`<script src="https://cdn.evil.com/...">`)
- Outbound requests to anywhere we didn't explicitly allow

## API keys

- Stored in IndexedDB via Dexie inside the `settings` table. (Dexie writes to IndexedDB, which Chrome encrypts as part of the user profile under modern OSes.)
- Optional hardening: switch to `chrome.storage.local` with `chrome.storage.session` for ephemeral copies, or use `crypto.subtle` to AES-GCM-wrap the keys with a key derived from a user passphrase. Out of scope for MVP but a clean place to extend.

## What we do NOT do

- We never send your API keys, lead data, or notes to any server we operate. There is no LeadLoom server.
- We never auto-message anyone. Every outreach action is a user click.
- We never scrape Facebook. Every lead comes from an API the user authorized, an opt-in form, or a manual save.
- We never include analytics/telemetry SDKs. (You're welcome to add one for your own deployment — see `docs/DEPLOYMENT.md`.)

## Responsible disclosure

If you find a security issue, please email `security@example.com` (replace with your address) before opening a public issue. We aim to acknowledge within 72 hours.
