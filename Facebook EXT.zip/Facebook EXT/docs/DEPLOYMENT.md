# Deployment

LeadLoom is a Chrome extension, so "deployment" means one of:

1. **Personal / team use** — load unpacked on each developer machine (covered in [`INSTALLATION.md`](INSTALLATION.md)).
2. **Internal distribution** — package the build as a `.zip` and side-load it on managed Chrome installs via enterprise policy.
3. **Public distribution** — publish to the Chrome Web Store.

This doc covers options 2 and 3.

---

## 2. Internal / enterprise distribution

### Step 2.1 — Package the extension

```bash
npm run build
cd dist
zip -r ../leadloom-0.1.0.zip .
```

(Or use the `npm run package` script if you wire one up.)

### Step 2.2 — Sign the package (optional but recommended)

Chrome can package as a `.crx` if you provide a private key:

```bash
chrome --pack-extension=./dist --pack-extension-key=./leadloom.pem
```

This emits `dist.crx` and (on first run) a `.pem`. Keep the `.pem` safe — it identifies your extension permanently.

### Step 2.3 — Distribute via Chrome Enterprise policy

Drop the `.crx` on an internal HTTPS host, then push a policy:

```json
{
  "ExtensionInstallForcelist": [
    "<extension-id>;https://internal.example.com/leadloom/updates.xml"
  ]
}
```

Where `updates.xml` is the standard Chrome update manifest. Docs: <https://support.google.com/chrome/a/answer/9296680>.

---

## 3. Chrome Web Store

### 3.1 — Prep

- Make sure `manifest.json` `name`, `description`, `version` are accurate.
- Add real icons in `public/icons/` (16, 32, 48, 128 px).
- Take **5 screenshots** at 1280×800 or 640×400 of the popup, leads table, drawer, composer, settings.
- Write a **privacy policy** describing what data is stored and where (template below).

### 3.2 — Upload

1. Go to <https://chrome.google.com/webstore/devconsole>. One-time $5 fee.
2. **New item** → upload `leadloom-0.1.0.zip`.
3. Fill in:
   - **Store listing**: name, summary, description, category (Productivity), language, screenshots, promo tile.
   - **Privacy practices**: tick each data type your extension uses.
     - `authentication_info` (API keys)
     - `web_history` (URLs of saved posts)
     - `personal_communications` (lead names/messages)
   - **Justifications** for each `host_permission` and broad permission.
   - **Single purpose**: "Capture, organize, and respond to Facebook leads using official APIs."
4. **Submit for review.** Reviews typically take a few business days; broad host permissions (we use specific ones, which helps) or `<all_urls>` claims slow it down.

### 3.3 — Privacy policy template

```
LeadLoom is a Chrome extension that helps individuals organize Facebook leads.

Data we collect:
- Lead data you choose to save (names, message text, post URLs, your notes)
- API keys you paste in Settings (Anthropic, OpenAI, Meta)

Where it lives:
- All data is stored locally in your browser's IndexedDB and chrome.storage.local.
- LeadLoom has no server. We do not collect, transmit, or sell your data.

Third parties:
- When you use AI features, your lead text is sent directly from your browser to
  Anthropic (and/or OpenAI) under their terms of service.
- When you connect Meta Lead Ads, your access token is sent from your browser to
  graph.facebook.com under Meta's terms of service.

Removal:
- Uninstalling the extension deletes all stored data.

Contact: <your-email>
```

Adapt for your jurisdiction (GDPR / CCPA disclosures, DPO contact, etc.) before publishing.

---

## CI/CD

Minimal GitHub Actions workflow to build and attach a zipped extension to every tag:

```yaml
name: release
on:
  push:
    tags: ['v*']
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci
      - run: npm run build
      - run: cd dist && zip -r ../leadloom-${{ github.ref_name }}.zip .
      - uses: softprops/action-gh-release@v2
        with:
          files: leadloom-*.zip
```

For Chrome Web Store auto-upload, see <https://github.com/PlasmoHQ/bpp>.

---

## Versioning

- Bump `manifest.json` → `"version"` *and* `package.json` → `"version"` in lockstep.
- Tag releases as `v0.1.0`. Chrome Web Store only accepts higher version numbers per upload.

---

## Update strategy

- The Chrome Web Store auto-pushes new versions to all users within ~24h.
- For self-hosted distribution, increment `<updatecheck version="0.1.1">` in your `updates.xml`.

## Rollback

There's no Web Store "undo". Practical rollback is: bump version (e.g. `0.1.2` → `0.1.3`), re-upload the older code as the new version, ship.
