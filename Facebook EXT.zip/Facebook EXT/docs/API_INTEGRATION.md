# API integration guide

LeadLoom talks to three external APIs. All calls originate from the MV3 service worker so your API keys never end up in a content script (and therefore never end up readable by the host page).

---

## 1. Anthropic Claude

**What it powers**: Lead intent scoring, message drafting, message rewriting.

### Get a key

1. Sign up at <https://console.anthropic.com>.
2. **API Keys** → **Create Key** → copy `sk-ant-…`.
3. LeadLoom dashboard → **Settings** → paste into **Anthropic API key**.

### Endpoint & headers we send

```
POST https://api.anthropic.com/v1/messages
x-api-key: sk-ant-…
anthropic-version: 2023-06-01
anthropic-dangerous-direct-browser-access: true
content-type: application/json
```

The `anthropic-dangerous-direct-browser-access` header is required when calling Anthropic from a browser-like origin (which a Chrome extension is). Per Anthropic's docs, this opt-in acknowledges that the key is being sent from a non-server context — which is fine for a single-user developer tool but **don't ship LeadLoom configured with a shared key**. Each user provides their own key.

### Model

Default: **`claude-sonnet-4-6`**. To change, edit `ANTHROPIC_MODEL` in `src/lib/api/ai.ts`.

### Cost estimate

Intent scoring: ~250 input tokens + ~80 output tokens per lead ≈ ~$0.001 per lead at current Sonnet pricing. Message drafting is ~2× that.

---

## 2. OpenAI (optional fallback)

**What it powers**: Same as Claude — runs only if Anthropic is missing or fails.

### Get a key

1. <https://platform.openai.com/api-keys> → **Create new secret key** → `sk-…`.
2. Dashboard → **Settings** → paste into **OpenAI API key**.

### Endpoint

```
POST https://api.openai.com/v1/chat/completions
Authorization: Bearer sk-…
content-type: application/json
```

Default model: `gpt-4o-mini` (in `src/lib/api/ai.ts`).

---

## 3. Meta Graph API (Lead Ads + Page mentions)

**What it powers**: Pulling leads from Lead Ads forms, and surfacing public posts that tagged your Page.

This is the part that takes the most work because Meta's Lead Ads access requires App Review.

### Step 3.1 — Create a Meta app

1. Go to <https://developers.facebook.com/apps> → **Create App** → choose **Business**.
2. App name → save.

### Step 3.2 — Add products

Add these to your app:

- **Facebook Login for Business**
- **Marketing API** (gives you Lead Ads endpoints)
- **Webhooks** (optional — for push-based lead delivery instead of polling)

### Step 3.3 — Generate a long-lived Page access token

The easy path for personal/internal use (avoiding App Review entirely):

1. **Graph API Explorer**: <https://developers.facebook.com/tools/explorer>
2. Select your app at the top.
3. **User or Page** → **Get User Access Token**.
4. Tick these permissions:
   - `pages_show_list`
   - `pages_read_engagement`
   - `leads_retrieval`
   - `pages_manage_metadata`
   - `pages_messaging` (only if you want to read inbox messages)
5. Click **Generate Access Token** and approve.
6. You now have a short-lived **user token**. Extend it:
   ```
   GET https://graph.facebook.com/v21.0/oauth/access_token
       ?grant_type=fb_exchange_token
       &client_id={APP_ID}
       &client_secret={APP_SECRET}
       &fb_exchange_token={SHORT_LIVED_USER_TOKEN}
   ```
   Response includes a 60-day user token.
7. Convert that to a **never-expiring Page token**:
   ```
   GET https://graph.facebook.com/v21.0/me/accounts?access_token={LONG_LIVED_USER_TOKEN}
   ```
   Each `data[].access_token` is a **non-expiring Page access token** (as long as the user doesn't change their password or revoke).
8. Paste that Page token into LeadLoom → **Settings** → **Meta access token**.

> Long-term, for production multi-tenant use, you'll need App Review for `leads_retrieval` and OAuth-based onboarding instead of paste-a-token.

### Step 3.4 — Endpoints we call

| Endpoint | Permission | Purpose |
|---|---|---|
| `GET /me/accounts` | `pages_show_list` | List Pages the user admins |
| `GET /{page-id}/leadgen_forms` | `leads_retrieval` | List Lead Ads forms attached to a Page |
| `GET /{form-id}/leads` | `leads_retrieval` | Pull form submissions (paginated) |
| `GET /{page-id}/tagged` | `pages_read_engagement` | Public posts that mentioned the Page |

All wrapped in `src/lib/api/meta.ts`.

### Step 3.5 — Webhook alternative (optional, advanced)

Polling is fine for low volumes. For real-time leads:

1. Stand up an HTTPS endpoint (Cloud Run / Vercel / fly.io) that verifies Meta's `hub.challenge` and stores incoming `leadgen` events.
2. In Meta App Dashboard → **Webhooks** → subscribe to the `leadgen` field on the Page object.
3. Have LeadLoom poll *your* endpoint instead of Meta. This sidesteps Meta rate limits.

(Out of scope for this MVP — see roadmap.)

---

## Rate limits

| Provider | Limit | Our behavior |
|---|---|---|
| Anthropic | Tier-based RPM/TPM | One request per user action; sync batches sequentially |
| OpenAI | Tier-based | Same as above |
| Meta Graph | ~200 calls/hour/user (BUC) | Sync runs every 15 min by default; one request per Page per cycle |

If you set the **Sync interval** below 5 minutes you'll see 429s from Meta — LeadLoom clamps it to ≥5.
