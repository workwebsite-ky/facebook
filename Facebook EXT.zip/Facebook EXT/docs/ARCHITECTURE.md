# Architecture

## Why this shape

LeadLoom is a Manifest V3 extension that behaves like a small local web app. Every piece exists for a specific reason driven by MV3 constraints:

| Constraint | Consequence |
|---|---|
| Service workers are short-lived and have no DOM | Persistent state lives in IndexedDB; API keys live in `chrome.storage.local` (read by the worker on demand) |
| Content scripts run in an isolated world but share the page DOM | Used only to inject a single floating button — no data collection logic |
| MV3 forbids remote code | Vite + `@crxjs/vite-plugin` bundles everything; we never `eval` or fetch JS |
| CSP blocks inline scripts in extension pages | Tailwind via PostCSS at build time, no runtime style injection |

## Runtime topology

```
┌─────────────┐         ┌─────────────┐         ┌──────────────┐
│  Popup UI   │◄──────►│  Service    │◄──────►│  Dashboard   │
│  (React)    │ runtime │  Worker     │ runtime │  (React SPA) │
└──────┬──────┘ messages └──────┬──────┘ messages └──────┬──────┘
       │                       │                        │
       │                       │ uses                   │
       │                       ▼                        │
       │              ┌────────────────┐                │
       │              │ IndexedDB      │                │
       └─────uses────►│ (Dexie)        │◄────uses───────┘
                      └────────────────┘
                              ▲
                              │ direct
                ┌─────────────┼──────────────┐
                │             │              │
        ┌───────┴──────┐ ┌────┴────┐ ┌──────┴───────┐
        │ Anthropic    │ │ OpenAI  │ │ Meta Graph   │
        │ Messages API │ │ (alt.)  │ │ API v21      │
        └──────────────┘ └─────────┘ └──────────────┘
```

The content script (`src/content/facebook-content.ts`) lives in a separate isolated world on `*.facebook.com` and only emits `lead:save` messages to the worker. It never reads sensitive data or scrapes.

## Data flow

### Inbound: a new Lead Ads submission

1. `chrome.alarms` fires `leadloom.sync` (default every 15 min).
2. Worker loads `Settings` → reads `metaAccessToken` and `metaPageIds`.
3. For each Page → `listForms` → `fetchFormLeads` → `toCrmLead`.
4. `isDuplicate` check, then `upsertLead`.
5. `scoreLead` runs heuristic + (optionally) Claude to assign temperature + score.
6. If `notifyOnHot` and result is hot → `chrome.notifications.create`.
7. Dashboard's `useLiveQuery(db.leads…)` re-renders automatically.

### Outbound: composing a message

1. User opens the lead drawer in the dashboard.
2. Clicks "Draft with AI" → React sends `ai:draftMessage` to worker.
3. Worker loads `Settings`, calls Claude (or OpenAI), returns `DraftedMessage`.
4. Composer writes to clipboard on "Copy" and logs `OutreachLog{action: 'copied'}`.
5. User opens Messenger themselves and clicks send.

## Database schema

See `src/lib/db/schema.ts`. Five stores:

- **leads** — primary entity. Indexes on `stage`, `temperature`, `score`, `createdAt`, `followUpAt`, `source`, multi-entry on `matchedKeywords` and `tags` for fast filtering.
- **keywords** — phrases the user wants to watch for. Unique index on `phrase` prevents duplicates.
- **templates** — saved message templates.
- **outreach** — append-only log of every copy / open-messenger / draft action. Indexed by `leadId`.
- **settings** — singleton row (`id: "default"`).

### Migrations

Dexie versioning: every schema change adds a new `this.version(N).stores({...})` block, never modifies an existing one. Add `.upgrade(tx => …)` when columns require backfill.

## Lead scoring pipeline

`src/lib/scoring/index.ts` is the single entrypoint:

```
text ──► heuristicScore (regex + word lists)
         ↓
       baseline score (0–100)
         ↓
   AI enabled?  ──► Claude / OpenAI returns {temperature, score, category, urgencyMarkers}
         ↓
   + engagement boost (likes + 2×comments + 3×shares, capped at +15)
   + recency boost   (≤1h=+10, ≤6h=+7, ≤24h=+4, ≤72h=+1)
         ↓
   clamp(0, 100) → temperature ← derived (≥70 hot, ≥40 warm, else cold)
         ↓
   upsertLead
```

The local heuristic exists so the CRM remains useful when AI keys are missing or the user is offline.

## Security model

- **API keys**: stored in `chrome.storage.local` and read by the service worker only. They never reach a content script (so a compromised host page can't exfil them via `postMessage` or DOM).
- **No remote code**: bundled at build time. Manifest CSP allows only `'self'` for `script-src`.
- **`host_permissions`** are scoped to the three providers we actually call (Anthropic, OpenAI, Graph). No broad `<all_urls>`.
- **Content script CSP**: lives in Facebook's CSP context, so it cannot inject scripts back into Facebook — only DOM nodes (button, toast).

More in `docs/SECURITY.md`.

## Build pipeline

`vite build` runs `@crxjs/vite-plugin`, which:

1. Reads `manifest.json`, follows each `js`/`html` entry as a Vite input.
2. Emits hashed bundles into `dist/assets/` and rewrites the manifest references.
3. Copies icons and `web_accessible_resources` paths.
4. In dev mode, sets up HMR over a local WebSocket (use `npm run dev`).

## Extending the extension

Common changes:

| Want to… | Edit |
|---|---|
| Add a new pipeline stage | `src/types/index.ts` (LEAD_STAGES) + `LeadTable.tsx` color map |
| Swap AI provider | `src/lib/api/ai.ts` — add a new branch in `scoreIntent` / `draftMessage` |
| Pull from a different source | New file in `src/lib/api/`, wire into `syncFromMeta` in the worker |
| Add a CRM field | Update `Lead` type, bump Dexie version with an upgrade, add a UI control in `LeadDrawer.tsx` |
| Customize scoring | `src/lib/scoring/index.ts` — change weights or replace the heuristic word lists |
