# Installation

## Prerequisites

- **Node.js 20+** and **npm 10+** (or pnpm/yarn — adjust commands)
- **Google Chrome 114+** (Manifest V3 + service worker module support)
- *(Optional)* **Anthropic API key** for AI scoring and message drafting
- *(Optional)* **OpenAI API key** as a fallback
- *(Optional)* **Meta developer account** if you want Lead Ads sync — see [`API_INTEGRATION.md`](API_INTEGRATION.md)

---

## 1. Install dependencies

```bash
git clone <your-repo>
cd leadloom
npm install
```

## 2. Build the extension

```bash
npm run build
```

This produces a fully-bundled extension in `dist/`. The folder includes the rewritten `manifest.json`, bundled JS/CSS, and your icons.

For active development:

```bash
npm run dev      # rebuilds on change; reload the extension in chrome://extensions
```

## 3. Load into Chrome

1. Open **`chrome://extensions`** in Chrome.
2. Toggle **Developer mode** on (top-right).
3. Click **Load unpacked**.
4. Select the `dist/` folder (not the project root).
5. You should see **LeadLoom** appear with its icon. Pin it to the toolbar.

> If you change `manifest.json` or any background code, click the circular **Reload** button next to the extension card in `chrome://extensions`.

## 4. First-run setup

1. Click the **LeadLoom** toolbar icon → **View all** → opens the dashboard in a new tab.
2. Go to **Settings**:
   - **AI**: paste your Anthropic key (recommended). If you only have OpenAI, paste that — both fields can be filled and Claude is preferred.
   - **Default tone**: pick the voice the AI composer should default to.
3. *(Optional)* **Meta Lead Ads**:
   - Paste a Page access token (see [`API_INTEGRATION.md`](API_INTEGRATION.md) for how to generate one with the right scopes).
   - Click **Fetch my Pages** and tick the Pages you want to sync from.
   - Set **Sync interval** (15 min is sensible).
4. Go to **Keywords** — the extension ships with a starter list; add or remove as you like.

## 5. Test it

### Test path A — manual save

1. Navigate to any public Facebook post.
2. You should see a small **Save lead** pill in the bottom-right corner.
3. *(Optional)* Highlight some text in the post first — it'll be saved as the lead's content.
4. Click **Save lead**. A toast appears.
5. Open the dashboard → **Leads** — the new lead is there with an AI-assigned temperature.

### Test path B — Lead Ads sync

1. Settings → **Sync Meta** (or wait for the alarm).
2. If you have leads in any selected Page's Lead Ads forms, they appear in the dashboard within a couple of seconds.

### Test path C — AI drafting

1. Open any lead → drawer slides in.
2. **Draft with AI** → a personalized message appears in the composer.
3. **Copy message** copies it and logs the action. **Open Messenger** opens the right chat in a new tab — you still click send.

---

## Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| Extension fails to load with "Service worker registration failed" | Run `npm run build` again — make sure `dist/src/background/service-worker.js` exists. |
| AI calls return 401 | Wrong or expired API key. Settings → re-paste. |
| Meta sync returns "(#190) Error validating access token" | Token expired. Regenerate per [`API_INTEGRATION.md`](API_INTEGRATION.md). |
| Save button doesn't appear on Facebook | The URL must match a post-like pattern (post / video / share / group permalink). Refresh after install. |
| Dashboard shows zero leads after sync | Check the worker console: `chrome://extensions` → LeadLoom → "Service worker" → Inspect. |

## Uninstall / reset

- **chrome://extensions** → LeadLoom → **Remove** uninstalls the extension entirely and clears its storage.
- To wipe data without uninstalling, open the dashboard, open DevTools, run `await indexedDB.deleteDatabase('leadloom')`, then reload.
