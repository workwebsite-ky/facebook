# Icons

Replace these placeholders with real PNG icons before publishing.

Required sizes (square, transparent or solid background):

| File         | Size        | Used in                                    |
|--------------|-------------|--------------------------------------------|
| icon16.png   | 16 × 16     | Browser toolbar (HiDPI: pairs with 32)     |
| icon32.png   | 32 × 32     | Toolbar @2x, extension management page     |
| icon48.png   | 48 × 48     | chrome://extensions listing                |
| icon128.png  | 128 × 128   | Chrome Web Store, install dialog           |

## Quick way to generate

Take a single 512×512 source PNG of your logo and run:

```bash
brew install imagemagick   # or apt install imagemagick
for size in 16 32 48 128; do
  convert source.png -resize ${size}x${size} icon${size}.png
done
```

Or use https://www.iloveimg.com/resize-image — free, no signup.

## Design guidance

- Keep the mark legible at 16×16. Single-color logos work best.
- Avoid hairlines and small text — they vanish at small sizes.
- Match the in-app accent color (`#2563eb` blue) for brand consistency.
