/**
 * Seed templates that ship with a fresh install so users have something to
 * play with on day one. Loaded once on first run by the service worker.
 */

import type { MessageTemplate } from "@types/index";

export const SEED_TEMPLATES: Omit<MessageTemplate, "id" | "createdAt" | "updatedAt">[] = [
  {
    name: "Logo — friendly intro",
    tone: "friendly",
    tags: ["logo", "intro"],
    body: `Hey {{name}}, saw your post about needing a logo. I design brand marks for small businesses and would love to help. Could you share a bit about what your business does?`,
  },
  {
    name: "Website — professional intro",
    tone: "professional",
    tags: ["website", "intro"],
    body: `Hi {{name}}, I noticed you're looking for someone to build a website. I build conversion-focused sites for service businesses. Happy to share a couple of recent examples — would that be useful?`,
  },
  {
    name: "Shopify expert — direct",
    tone: "direct",
    tags: ["shopify", "intro"],
    body: `Hi {{name}}, I build and optimize Shopify stores. If you're still looking, I can walk you through a quick plan and a price. Want me to send it over?`,
  },
  {
    name: "Soft follow-up (3 days)",
    tone: "casual",
    tags: ["follow-up"],
    body: `Hey {{name}}, just bumping this in case it got buried. Still happy to help with {{keyword}} if you're looking — no pressure.`,
  },
];
