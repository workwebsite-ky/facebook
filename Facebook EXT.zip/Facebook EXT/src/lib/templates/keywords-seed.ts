/**
 * Default keywords shipped with the extension. These are NOT used to scrape
 * Facebook — they're used to match against text the user manually captures
 * or that arrives via Lead Ads / Page mentions.
 */

export const SEED_KEYWORDS: string[] = [
  "need logo",
  "looking for logo designer",
  "need website",
  "looking for web developer",
  "need flyer",
  "need graphic designer",
  "looking for shopify expert",
  "need social media manager",
  "looking for wordpress developer",
  "hiring designer",
  "anyone make website",
];
