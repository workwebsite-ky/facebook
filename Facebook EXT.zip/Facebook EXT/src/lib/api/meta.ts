/**
 * Meta Graph API client — ToS-safe lead intake.
 *
 * What this does (official, supported endpoints):
 *  - GET /me/accounts                                  → list user's Pages
 *  - GET /{page-id}/leadgen_forms                      → forms attached to a Page
 *  - GET /{form-id}/leads                              → leads from a Lead Ad form
 *  - GET /{page-id}/tagged                             → public posts that tagged the Page
 *  - GET /{page-id}/conversations (with manage_messages) → messages sent TO the Page
 *
 * What this does NOT do:
 *  - Scrape user profiles, posts, or groups from the public site.
 *  - Search Facebook for keywords. (No such Graph endpoint exists.)
 *  - Send messages on the user's behalf. (Page-to-user replies require user opt-in
 *    via Messenger Platform and the 24-hour window; out of scope for this MVP.)
 *
 * Required token scopes (for the Page admin granting access):
 *   pages_show_list, pages_read_engagement, leads_retrieval,
 *   pages_manage_metadata, pages_messaging (optional, for inbox read).
 *
 * See docs/API_INTEGRATION.md for full setup instructions.
 */

import type { Lead } from "@types/index";
import { now, uid } from "@lib/utils";

const GRAPH = "https://graph.facebook.com/v21.0";

export class MetaApiError extends Error {
  constructor(public status: number, public body: string) {
    super(`Meta API ${status}: ${body}`);
  }
}

async function gfetch<T>(
  path: string,
  token: string,
  params: Record<string, string> = {},
): Promise<T> {
  const url = new URL(GRAPH + path);
  url.searchParams.set("access_token", token);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);

  const res = await fetch(url.toString(), { method: "GET" });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new MetaApiError(res.status, text);
  }
  return res.json() as Promise<T>;
}

// ---------------------------------------------------------------------------
// Pages
// ---------------------------------------------------------------------------

export interface MetaPage {
  id: string;
  name: string;
  category?: string;
  access_token?: string;
}

export async function listPages(userToken: string): Promise<MetaPage[]> {
  const res = await gfetch<{ data: MetaPage[] }>("/me/accounts", userToken, {
    fields: "id,name,category,access_token",
  });
  return res.data ?? [];
}

// ---------------------------------------------------------------------------
// Lead Ads
// ---------------------------------------------------------------------------

interface RawLeadgenLead {
  id: string;
  created_time: string;
  ad_id?: string;
  form_id?: string;
  campaign_name?: string;
  field_data: Array<{ name: string; values: string[] }>;
}

export interface LeadgenForm {
  id: string;
  name: string;
  status: string;
  leads_count?: number;
}

export async function listForms(pageId: string, pageToken: string): Promise<LeadgenForm[]> {
  const res = await gfetch<{ data: LeadgenForm[] }>(`/${pageId}/leadgen_forms`, pageToken, {
    fields: "id,name,status,leads_count",
  });
  return res.data ?? [];
}

export async function fetchFormLeads(formId: string, pageToken: string): Promise<RawLeadgenLead[]> {
  // Paginate to gather all available leads.
  let url = `${GRAPH}/${formId}/leads?access_token=${pageToken}&fields=id,created_time,ad_id,form_id,campaign_name,field_data`;
  const all: RawLeadgenLead[] = [];
  let safety = 50;
  while (url && safety-- > 0) {
    const res = await fetch(url);
    if (!res.ok) throw new MetaApiError(res.status, await res.text());
    const j: { data: RawLeadgenLead[]; paging?: { next?: string } } = await res.json();
    all.push(...(j.data ?? []));
    url = j.paging?.next ?? "";
  }
  return all;
}

/** Convert a raw Lead Ads response into the CRM's Lead shape. */
export function toCrmLead(raw: RawLeadgenLead, sourceMeta?: { pageId?: string; formName?: string }): Lead {
  const fields: Record<string, string> = {};
  for (const f of raw.field_data) fields[f.name.toLowerCase()] = f.values[0] ?? "";

  const name = fields["full_name"] || fields["name"] || fields["first_name"] || "Unknown";
  const summary = Object.entries(fields)
    .map(([k, v]) => `${k}: ${v}`)
    .join("\n");

  return {
    id: uid(),
    name,
    profileUrl: undefined,
    country: fields["country"],
    language: undefined,
    postContent: summary,
    postCreatedAt: new Date(raw.created_time).getTime(),
    postUrl: undefined,
    groupName: sourceMeta?.formName,
    matchedKeywords: [],
    stage: "new",
    temperature: "warm",
    score: 50,
    source: "lead_ads",
    tags: ["lead_ads"],
    archived: false,
    createdAt: now(),
    updatedAt: now(),
  };
}

// ---------------------------------------------------------------------------
// Page mentions (public posts that tagged the user's Page)
// ---------------------------------------------------------------------------

export interface PageMention {
  id: string;
  message?: string;
  created_time: string;
  permalink_url?: string;
  from?: { id: string; name: string };
}

export async function fetchPageMentions(pageId: string, pageToken: string): Promise<PageMention[]> {
  const res = await gfetch<{ data: PageMention[] }>(`/${pageId}/tagged`, pageToken, {
    fields: "id,message,created_time,permalink_url,from",
    limit: "50",
  });
  return res.data ?? [];
}
