/**
 * AI client — Claude (primary) with OpenAI fallback.
 *
 * Both calls run from the extension's background service worker so the API
 * key never lands in a content-script context exposed to the host page.
 *
 * We use the REST APIs directly (not the SDK) to keep the bundle small and
 * to avoid Node-only dependencies inside the MV3 worker.
 */

import type { DraftedMessage, IntentAnalysis, Lead, MessageTemplate } from "@types/index";
import { safeJson, truncate } from "@lib/utils";

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const ANTHROPIC_MODEL = "claude-sonnet-4-6";
const OPENAI_URL = "https://api.openai.com/v1/chat/completions";
const OPENAI_MODEL = "gpt-4o-mini";

export class AiUnavailableError extends Error {
  constructor() {
    super("No AI provider configured. Add an Anthropic or OpenAI key in Settings.");
  }
}

// ---------------------------------------------------------------------------
// Intent / scoring
// ---------------------------------------------------------------------------

const INTENT_SYSTEM = `You are a lead-qualification assistant for a small services agency.
Given a short snippet of text from a public Facebook post or form submission, classify the author's intent to hire a service provider RIGHT NOW.
Return STRICT JSON only:
{
  "temperature": "hot" | "warm" | "cold",
  "score": 0-100,
  "category": short label like "logo" | "website" | "shopify" | "social media" | "other",
  "urgencyMarkers": [up to 4 short phrases],
  "rationale": "one sentence"
}
Rules:
- "hot" = explicitly hiring NOW with budget or urgency words (need urgently, hiring today, budget ready, asap, dm me).
- "warm" = clear need but no urgency or already comparing options.
- "cold" = vague mention, already hired, asking for free help, or off-topic.
- If the post says "already hired" / "no longer need", score MUST be < 20.
- Do NOT include any text outside the JSON object.`;

interface AiKeys {
  anthropic?: string;
  openai?: string;
}

export async function scoreIntent(text: string, keys: AiKeys): Promise<IntentAnalysis> {
  const snippet = truncate(text || "", 1500);

  if (keys.anthropic) {
    try {
      return await scoreWithClaude(snippet, keys.anthropic);
    } catch (e) {
      console.warn("[ai] Claude scoring failed, falling back:", e);
    }
  }
  if (keys.openai) {
    try {
      return await scoreWithOpenAi(snippet, keys.openai);
    } catch (e) {
      console.warn("[ai] OpenAI scoring failed:", e);
    }
  }
  // Local heuristic fallback — never throws, so the CRM always works offline.
  return heuristicScore(snippet);
}

async function scoreWithClaude(text: string, apiKey: string): Promise<IntentAnalysis> {
  const res = await fetch(ANTHROPIC_URL, {
    method: "POST",
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
      // Required for browser/extension origins:
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: ANTHROPIC_MODEL,
      max_tokens: 300,
      system: INTENT_SYSTEM,
      messages: [{ role: "user", content: text }],
    }),
  });
  if (!res.ok) throw new Error(`Claude ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const out = j?.content?.[0]?.text ?? "";
  return parseIntentJson(out, "ai");
}

async function scoreWithOpenAi(text: string, apiKey: string): Promise<IntentAnalysis> {
  const res = await fetch(OPENAI_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: INTENT_SYSTEM },
        { role: "user", content: text },
      ],
    }),
  });
  if (!res.ok) throw new Error(`OpenAI ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const out = j?.choices?.[0]?.message?.content ?? "";
  return parseIntentJson(out, "ai");
}

function parseIntentJson(raw: string, method: "ai" | "heuristic"): IntentAnalysis {
  // Strip code fences if model added them.
  const cleaned = raw.replace(/```json\s*|\s*```/g, "").trim();
  const parsed = safeJson<Partial<IntentAnalysis>>(cleaned, {});
  return {
    temperature: (parsed.temperature ?? "cold") as IntentAnalysis["temperature"],
    score: Math.max(0, Math.min(100, Number(parsed.score) || 0)),
    category: parsed.category,
    urgencyMarkers: parsed.urgencyMarkers ?? [],
    rationale: parsed.rationale ?? "",
    method,
  };
}

// ---------------------------------------------------------------------------
// Local heuristic fallback
// ---------------------------------------------------------------------------

const URGENT_WORDS = [
  "urgent",
  "urgently",
  "asap",
  "today",
  "right now",
  "immediately",
  "budget ready",
  "hiring now",
  "dm me",
  "send me a quote",
];
const COLD_WORDS = ["already hired", "no longer need", "found someone", "free", "for free"];
const CATEGORY_MAP: Array<[RegExp, string]> = [
  [/logo|brand mark/i, "logo"],
  [/website|web ?site|landing page/i, "website"],
  [/shopify|woocommerce/i, "shopify"],
  [/wordpress/i, "wordpress"],
  [/flyer|poster|brochure/i, "flyer"],
  [/social media|smm|instagram manager/i, "social media"],
  [/graphic design|designer/i, "graphic design"],
];

export function heuristicScore(text: string): IntentAnalysis {
  const t = (text || "").toLowerCase();
  const urgency = URGENT_WORDS.filter((w) => t.includes(w));
  const cold = COLD_WORDS.some((w) => t.includes(w));
  let score = 30;
  if (urgency.length) score += Math.min(50, urgency.length * 20);
  if (/need|looking for|hire/.test(t)) score += 15;
  if (/budget|\$|usd|inr|pkr/.test(t)) score += 10;
  if (cold) score = Math.min(score, 15);

  const temperature: IntentAnalysis["temperature"] = score >= 70 ? "hot" : score >= 40 ? "warm" : "cold";

  let category: string | undefined;
  for (const [re, name] of CATEGORY_MAP) {
    if (re.test(text)) {
      category = name;
      break;
    }
  }

  return {
    temperature,
    score: Math.min(100, score),
    category,
    urgencyMarkers: urgency,
    rationale: cold
      ? "Post indicates the need is already met."
      : urgency.length
        ? "Urgency language present."
        : "Need expressed without strong urgency.",
    method: "heuristic",
  };
}

// ---------------------------------------------------------------------------
// Message drafting
// ---------------------------------------------------------------------------

const DRAFT_SYSTEM = (tone: MessageTemplate["tone"]) => `You are helping a freelancer write the first outreach message to a Facebook lead.
Write ONE short message (40–80 words) in a ${tone} tone.
Hard rules:
- Reference the lead's stated need naturally; do NOT copy their wording verbatim.
- No emojis unless tone is "casual".
- No sales jargon, no "I hope this finds you well", no "circle back".
- Plain text only, no markdown.
- End with one soft question that invites a reply.`;

export async function draftMessage(
  lead: Lead,
  tone: MessageTemplate["tone"],
  keys: AiKeys,
): Promise<DraftedMessage> {
  if (!keys.anthropic && !keys.openai) throw new AiUnavailableError();

  const user = [
    `Lead name: ${lead.name}`,
    lead.postContent ? `Their post / form response: """${truncate(lead.postContent, 800)}"""` : "",
    lead.matchedKeywords.length ? `Matched keyword(s): ${lead.matchedKeywords.join(", ")}` : "",
  ]
    .filter(Boolean)
    .join("\n");

  if (keys.anthropic) {
    const res = await fetch(ANTHROPIC_URL, {
      method: "POST",
      headers: {
        "x-api-key": keys.anthropic,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model: ANTHROPIC_MODEL,
        max_tokens: 400,
        system: DRAFT_SYSTEM(tone),
        messages: [{ role: "user", content: user }],
      }),
    });
    if (!res.ok) throw new Error(`Claude ${res.status}: ${await res.text()}`);
    const j = await res.json();
    const body = (j?.content?.[0]?.text ?? "").trim();
    return { body, meta: { tone, wordCount: body.split(/\s+/).length } };
  }

  const res = await fetch(OPENAI_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${keys.openai}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      messages: [
        { role: "system", content: DRAFT_SYSTEM(tone) },
        { role: "user", content: user },
      ],
    }),
  });
  if (!res.ok) throw new Error(`OpenAI ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const body = (j?.choices?.[0]?.message?.content ?? "").trim();
  return { body, meta: { tone, wordCount: body.split(/\s+/).length } };
}

/** Rewrite an existing message — used by the "Rewrite" button in the composer. */
export async function rewriteMessage(
  current: string,
  instruction: string,
  keys: AiKeys,
): Promise<string> {
  if (!keys.anthropic && !keys.openai) throw new AiUnavailableError();
  const system = "Rewrite the user's message per the instruction. Return only the rewritten text, no commentary.";
  const user = `Instruction: ${instruction}\n\nMessage:\n${current}`;
  if (keys.anthropic) {
    const res = await fetch(ANTHROPIC_URL, {
      method: "POST",
      headers: {
        "x-api-key": keys.anthropic,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model: ANTHROPIC_MODEL,
        max_tokens: 400,
        system,
        messages: [{ role: "user", content: user }],
      }),
    });
    if (!res.ok) throw new Error(`Claude ${res.status}: ${await res.text()}`);
    const j = await res.json();
    return (j?.content?.[0]?.text ?? "").trim();
  }
  const res = await fetch(OPENAI_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${keys.openai}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
  });
  if (!res.ok) throw new Error(`OpenAI ${res.status}: ${await res.text()}`);
  const j = await res.json();
  return (j?.choices?.[0]?.message?.content ?? "").trim();
}
