/**
 * Export utilities — CSV, XLSX, JSON. All run in the renderer (popup or
 * dashboard) so users get a normal browser download dialog.
 */

import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import type { Lead } from "@types/index";

/** Columns surfaced in exports. Keep in sync with LeadTable for parity. */
const COLUMNS: Array<{ key: keyof Lead | "engagementSummary"; label: string }> = [
  { key: "name", label: "Name" },
  { key: "profileUrl", label: "Profile URL" },
  { key: "postContent", label: "Post / message" },
  { key: "matchedKeywords", label: "Matched keywords" },
  { key: "stage", label: "Stage" },
  { key: "temperature", label: "Temperature" },
  { key: "score", label: "Score" },
  { key: "source", label: "Source" },
  { key: "country", label: "Country" },
  { key: "language", label: "Language" },
  { key: "groupName", label: "Group" },
  { key: "postUrl", label: "Post URL" },
  { key: "postCreatedAt", label: "Posted at" },
  { key: "engagementSummary", label: "Engagement" },
  { key: "tags", label: "Tags" },
  { key: "notes", label: "Notes" },
  { key: "createdAt", label: "Captured at" },
];

function row(lead: Lead): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const c of COLUMNS) {
    if (c.key === "engagementSummary") {
      const e = lead.engagement;
      out[c.label] = e ? `likes:${e.likes ?? 0} comments:${e.comments ?? 0} shares:${e.shares ?? 0}` : "";
      continue;
    }
    const v = (lead as any)[c.key];
    if (Array.isArray(v)) out[c.label] = v.join(", ");
    else if (typeof v === "number" && (c.key === "postCreatedAt" || c.key === "createdAt"))
      out[c.label] = v ? new Date(v).toISOString() : "";
    else out[c.label] = v ?? "";
  }
  return out;
}

function fileTimestamp(): string {
  const d = new Date();
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
}

export function exportLeadsToJson(leads: Lead[]) {
  const blob = new Blob([JSON.stringify(leads, null, 2)], { type: "application/json" });
  saveAs(blob, `leadloom_${fileTimestamp()}.json`);
}

export function exportLeadsToCsv(leads: Lead[]) {
  const rows = leads.map(row);
  const ws = XLSX.utils.json_to_sheet(rows);
  const csv = XLSX.utils.sheet_to_csv(ws);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  saveAs(blob, `leadloom_${fileTimestamp()}.csv`);
}

export function exportLeadsToXlsx(leads: Lead[]) {
  const rows = leads.map(row);
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Leads");
  const out = XLSX.write(wb, { type: "array", bookType: "xlsx" });
  const blob = new Blob([out], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  saveAs(blob, `leadloom_${fileTimestamp()}.xlsx`);
}
