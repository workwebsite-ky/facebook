/**
 * chrome.notifications wrapper. Used from the service worker when a new
 * hot lead arrives via Lead Ads sync or a Page mention.
 */

import type { Lead } from "@types/index";

export function notifyHotLead(lead: Lead) {
  chrome.notifications?.create(`lead-${lead.id}`, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("public/icons/icon128.png"),
    title: `Hot lead: ${lead.name}`,
    message: lead.postContent?.slice(0, 120) ?? "Open dashboard for details.",
    priority: 2,
  });
}

export function notifyError(title: string, message: string) {
  chrome.notifications?.create(`err-${Date.now()}`, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("public/icons/icon128.png"),
    title,
    message,
    priority: 1,
  });
}
