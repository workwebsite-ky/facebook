/**
 * Dexie schema for LeadLoom.
 *
 * Why Dexie over raw IndexedDB:
 *  - Promise-based, works inside MV3 service workers (Chrome 114+).
 *  - Compound indexes for the queries we need:
 *      leads: by stage+score, by temperature, by createdAt, by followUpAt.
 *      keywords: by active, by phrase.
 *
 * Versioning: add a new `.version()` block per schema change. Never modify
 * an existing version block — Dexie uses it for migrations.
 */

import Dexie, { type Table } from "dexie";
import type {
  Keyword,
  Lead,
  MessageTemplate,
  OutreachLog,
  Settings,
} from "@types/index";

export class LeadLoomDB extends Dexie {
  leads!: Table<Lead, string>;
  keywords!: Table<Keyword, string>;
  templates!: Table<MessageTemplate, string>;
  outreach!: Table<OutreachLog, string>;
  settings!: Table<Settings, "default">;

  constructor() {
    super("leadloom");

    this.version(1).stores({
      // & = unique primary, * = multi-entry index
      leads: "id, stage, temperature, score, createdAt, followUpAt, source, archived, *matchedKeywords, *tags",
      keywords: "id, &phrase, active, createdAt",
      templates: "id, name, tone, *tags, updatedAt",
      outreach: "id, leadId, action, createdAt",
      settings: "id",
    });
  }
}

export const db = new LeadLoomDB();
