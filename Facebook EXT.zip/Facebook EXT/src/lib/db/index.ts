/**
 * High-level DB operations. UI code should call these — not Dexie directly —
 * so we can swap the storage layer later (e.g. to a hosted backend) without
 * touching React components.
 */

import { db } from "./schema";
import type {
  ID,
  Lead,
  Keyword,
  MessageTemplate,
  OutreachLog,
  Settings,
  LeadStage,
} from "@types/index";
import { uid, now } from "@lib/utils";

// ---------------------------------------------------------------------------
// Leads
// ---------------------------------------------------------------------------

export async function listLeads(opts?: {
  stage?: LeadStage;
  temperature?: Lead["temperature"];
  minScore?: number;
  query?: string;
  includeArchived?: boolean;
  limit?: number;
}): Promise<Lead[]> {
  let coll = db.leads.orderBy("createdAt").reverse();
  let rows = await coll.toArray();

  if (!opts?.includeArchived) rows = rows.filter((l) => !l.archived);
  if (opts?.stage) rows = rows.filter((l) => l.stage === opts.stage);
  if (opts?.temperature) rows = rows.filter((l) => l.temperature === opts.temperature);
  if (opts?.minScore != null) rows = rows.filter((l) => l.score >= opts.minScore!);
  if (opts?.query) {
    const q = opts.query.toLowerCase();
    rows = rows.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.postContent?.toLowerCase().includes(q) ||
        l.matchedKeywords.some((k) => k.toLowerCase().includes(q)),
    );
  }
  if (opts?.limit) rows = rows.slice(0, opts.limit);
  return rows;
}

export async function getLead(id: ID) {
  return db.leads.get(id);
}

export async function upsertLead(partial: Partial<Lead> & { name: string }): Promise<Lead> {
  const ts = now();
  if (partial.id) {
    const existing = await db.leads.get(partial.id);
    if (existing) {
      const next: Lead = { ...existing, ...partial, updatedAt: ts };
      await db.leads.put(next);
      return next;
    }
  }
  const next: Lead = {
    id: partial.id ?? uid(),
    name: partial.name,
    profileUrl: partial.profileUrl,
    country: partial.country,
    language: partial.language,
    postContent: partial.postContent,
    postCreatedAt: partial.postCreatedAt,
    postUrl: partial.postUrl,
    groupName: partial.groupName,
    matchedKeywords: partial.matchedKeywords ?? [],
    engagement: partial.engagement,
    stage: partial.stage ?? "new",
    temperature: partial.temperature ?? "cold",
    score: partial.score ?? 0,
    source: partial.source ?? "manual_entry",
    notes: partial.notes,
    tags: partial.tags ?? [],
    followUpAt: partial.followUpAt,
    archived: partial.archived ?? false,
    createdAt: partial.createdAt ?? ts,
    updatedAt: ts,
  };
  await db.leads.put(next);
  return next;
}

/** Deduplicate by profileUrl (or name+postContent when URL is missing). */
export async function isDuplicate(input: Partial<Lead>): Promise<boolean> {
  if (input.profileUrl) {
    const hit = await db.leads.where({ profileUrl: input.profileUrl }).first();
    if (hit) return true;
  }
  if (input.name && input.postContent) {
    const hit = await db.leads
      .filter((l) => l.name === input.name && l.postContent === input.postContent)
      .first();
    if (hit) return true;
  }
  return false;
}

export async function deleteLead(id: ID) {
  await db.leads.delete(id);
}

export async function archiveLead(id: ID, archived = true) {
  await db.leads.update(id, { archived, updatedAt: now() });
}

export async function setStage(id: ID, stage: LeadStage) {
  await db.leads.update(id, { stage, updatedAt: now() });
}

// ---------------------------------------------------------------------------
// Keywords
// ---------------------------------------------------------------------------

export async function listKeywords(): Promise<Keyword[]> {
  return db.keywords.orderBy("createdAt").reverse().toArray();
}

export async function upsertKeyword(input: Partial<Keyword> & { phrase: string }): Promise<Keyword> {
  const ts = now();
  if (input.id) {
    await db.keywords.update(input.id, { ...input, lastUsedAt: input.lastUsedAt });
    return (await db.keywords.get(input.id))!;
  }
  const k: Keyword = {
    id: uid(),
    phrase: input.phrase,
    language: input.language,
    country: input.country,
    active: input.active ?? true,
    createdAt: ts,
  };
  await db.keywords.put(k);
  return k;
}

export async function deleteKeyword(id: ID) {
  await db.keywords.delete(id);
}

// ---------------------------------------------------------------------------
// Templates
// ---------------------------------------------------------------------------

export async function listTemplates(): Promise<MessageTemplate[]> {
  return db.templates.orderBy("updatedAt").reverse().toArray();
}

export async function upsertTemplate(input: Partial<MessageTemplate> & { name: string; body: string }): Promise<MessageTemplate> {
  const ts = now();
  if (input.id) {
    const existing = await db.templates.get(input.id);
    if (existing) {
      const next = { ...existing, ...input, updatedAt: ts } as MessageTemplate;
      await db.templates.put(next);
      return next;
    }
  }
  const t: MessageTemplate = {
    id: uid(),
    name: input.name,
    body: input.body,
    tags: input.tags ?? [],
    tone: input.tone ?? "friendly",
    createdAt: ts,
    updatedAt: ts,
  };
  await db.templates.put(t);
  return t;
}

export async function deleteTemplate(id: ID) {
  await db.templates.delete(id);
}

// ---------------------------------------------------------------------------
// Outreach log
// ---------------------------------------------------------------------------

export async function logOutreach(entry: Omit<OutreachLog, "id" | "createdAt">) {
  const o: OutreachLog = { id: uid(), createdAt: now(), ...entry };
  await db.outreach.put(o);
  return o;
}

export async function listOutreachForLead(leadId: ID) {
  return db.outreach.where("leadId").equals(leadId).reverse().sortBy("createdAt");
}

// ---------------------------------------------------------------------------
// Settings (singleton)
// ---------------------------------------------------------------------------

export const DEFAULT_SETTINGS: Settings = {
  id: "default",
  anthropicApiKey: undefined,
  openaiApiKey: undefined,
  metaAccessToken: undefined,
  metaPageIds: [],
  theme: "system",
  density: "comfortable",
  defaultTone: "friendly",
  minScoreFilter: 0,
  syncIntervalMinutes: 15,
  notifyOnHot: true,
  updatedAt: 0,
};

export async function getSettings(): Promise<Settings> {
  const row = await db.settings.get("default");
  return row ?? DEFAULT_SETTINGS;
}

export async function updateSettings(patch: Partial<Settings>): Promise<Settings> {
  const cur = await getSettings();
  const next: Settings = { ...cur, ...patch, id: "default", updatedAt: now() };
  await db.settings.put(next);
  return next;
}

// ---------------------------------------------------------------------------
// Analytics aggregates (used on Analytics page)
// ---------------------------------------------------------------------------

export async function analyticsSummary() {
  const leads = await db.leads.toArray();
  const total = leads.length;
  const byStage: Record<LeadStage, number> = {
    new: 0,
    contacted: 0,
    replied: 0,
    interested: 0,
    closed_won: 0,
    closed_lost: 0,
  };
  const byTemp = { hot: 0, warm: 0, cold: 0 };
  let scoreSum = 0;
  for (const l of leads) {
    byStage[l.stage] = (byStage[l.stage] ?? 0) + 1;
    byTemp[l.temperature] = (byTemp[l.temperature] ?? 0) + 1;
    scoreSum += l.score;
  }
  return {
    total,
    byStage,
    byTemperature: byTemp,
    avgScore: total ? Math.round(scoreSum / total) : 0,
  };
}
