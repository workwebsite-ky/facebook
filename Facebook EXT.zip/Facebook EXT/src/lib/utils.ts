/**
 * Tiny utilities shared across the codebase.
 */

import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** Conditional className merger (Tailwind-aware). */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/** UUID v4 (works in service worker — no node:crypto). */
export function uid(): string {
  return crypto.randomUUID();
}

/** Current epoch ms. Always use this instead of Date.now() so we can mock in tests. */
export function now(): number {
  return Date.now();
}

/**
 * Sleep helper — used ONLY for UX pacing (debounce-like effects).
 * Never use this to evade rate limits or detection systems.
 */
export function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/** Format a relative time like "3h ago". */
export function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  const w = Math.floor(d / 7);
  if (w < 5) return `${w}w ago`;
  return new Date(ts).toLocaleDateString();
}

/** Safe JSON parse. */
export function safeJson<T = unknown>(text: string, fallback: T): T {
  try {
    return JSON.parse(text) as T;
  } catch {
    return fallback;
  }
}

/** Truncate a string with ellipsis. */
export function truncate(s: string, n: number): string {
  if (!s) return "";
  return s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s;
}

/** Simple mustache-style template render. */
export function renderTemplate(body: string, vars: Record<string, string | undefined>): string {
  return body.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (_, key) => (vars[key] ?? "").toString());
}

/** Clamp helper. */
export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

/** Group array by a derived key. */
export function groupBy<T, K extends string>(rows: T[], fn: (r: T) => K): Record<K, T[]> {
  const out = {} as Record<K, T[]>;
  for (const row of rows) {
    const k = fn(row);
    (out[k] ||= []).push(row);
  }
  return out;
}
