/**
 * Lead scoring orchestrator.
 *
 * Combines local heuristics with optional AI scoring. The flow is:
 *  1. Heuristic pass (cheap, always runs)              → baseline score.
 *  2. If AI key is configured AND text >= 30 chars     → upgrade with Claude/OpenAI.
 *  3. Boost score by engagement signals + keyword fit.
 *  4. Persist back to the Lead row.
 */

import type { IntentAnalysis, Keyword, Lead, Settings } from "@types/index";
import { heuristicScore, scoreIntent } from "@lib/api/ai";
import { upsertLead } from "@lib/db";
import { clamp } from "@lib/utils";

export async function scoreLead(lead: Lead, settings: Settings): Promise<Lead> {
  const text = [lead.name, lead.postContent].filter(Boolean).join("\n");

  let analysis: IntentAnalysis;
  if (text.length >= 30 && (settings.anthropicApiKey || settings.openaiApiKey)) {
    analysis = await scoreIntent(text, {
      anthropic: settings.anthropicApiKey,
      openai: settings.openaiApiKey,
    });
  } else {
    analysis = heuristicScore(text);
  }

  // Engagement boost — caps at +15.
  const eng = lead.engagement;
  const engagementBoost = clamp(
    Math.round(((eng?.likes ?? 0) + (eng?.comments ?? 0) * 2 + (eng?.shares ?? 0) * 3) / 5),
    0,
    15,
  );

  // Recency boost — fresher post = better.
  let recencyBoost = 0;
  if (lead.postCreatedAt) {
    const ageHours = (Date.now() - lead.postCreatedAt) / 36e5;
    if (ageHours < 1) recencyBoost = 10;
    else if (ageHours < 6) recencyBoost = 7;
    else if (ageHours < 24) recencyBoost = 4;
    else if (ageHours < 72) recencyBoost = 1;
  }

  const score = clamp(analysis.score + engagementBoost + recencyBoost, 0, 100);
  const temperature = score >= 70 ? "hot" : score >= 40 ? "warm" : "cold";

  const updated: Lead = {
    ...lead,
    score,
    temperature,
    tags: dedup([
      ...lead.tags,
      analysis.category ? `cat:${analysis.category}` : "",
      `via:${analysis.method}`,
    ].filter(Boolean) as string[]),
  };

  return upsertLead(updated);
}

function dedup<T>(arr: T[]): T[] {
  return Array.from(new Set(arr));
}

/** Match a piece of text against the user's keyword list. Case-insensitive substring. */
export function matchKeywords(text: string, keywords: Keyword[]): string[] {
  const t = (text || "").toLowerCase();
  return keywords
    .filter((k) => k.active && t.includes(k.phrase.toLowerCase()))
    .map((k) => k.phrase);
}
