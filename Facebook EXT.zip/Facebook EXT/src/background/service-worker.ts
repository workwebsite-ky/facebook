/**
 * MV3 service worker — the extension's "backend".
 *
 * Responsibilities:
 *  1. Message routing between popup / dashboard / content script.
 *  2. Scheduled Meta API sync (Lead Ads + Page mentions) via chrome.alarms.
 *  3. AI scoring + drafting (so API keys live only here, never in content scripts).
 *  4. Seeding default keywords/templates on first install.
 *  5. Desktop notifications for hot leads.
 *
 * Service workers in MV3 are short-lived; DO NOT rely on top-level state
 * surviving across invocations. Persist anything you need in IndexedDB.
 */

import type { RuntimeMessage, RuntimeResponse, Lead } from "@types/index";
import {
  DEFAULT_SETTINGS,
  archiveLead,
  deleteLead,
  getLead,
  getSettings,
  isDuplicate,
  listKeywords,
  listLeads,
  listTemplates,
  logOutreach,
  setStage,
  updateSettings,
  upsertKeyword,
  upsertLead,
  upsertTemplate,
} from "@lib/db";
import { db } from "@lib/db/schema";
import { scoreLead, matchKeywords } from "@lib/scoring";
import { draftMessage } from "@lib/api/ai";
import { fetchFormLeads, fetchPageMentions, listForms, toCrmLead } from "@lib/api/meta";
import { SEED_TEMPLATES } from "@lib/templates/seed";
import { SEED_KEYWORDS } from "@lib/templates/keywords-seed";
import { notifyError, notifyHotLead } from "@lib/notifications";

const SYNC_ALARM = "leadloom.sync";

// ---------------------------------------------------------------------------
// Install / startup
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    await seedDefaults();
  }
  await rescheduleAlarm();
});

chrome.runtime.onStartup.addListener(async () => {
  await rescheduleAlarm();
});

async function seedDefaults() {
  const existingTemplates = await listTemplates();
  if (existingTemplates.length === 0) {
    for (const t of SEED_TEMPLATES) await upsertTemplate(t);
  }
  const existingKeywords = await listKeywords();
  if (existingKeywords.length === 0) {
    for (const phrase of SEED_KEYWORDS) await upsertKeyword({ phrase });
  }
  const s = await getSettings();
  if (s.updatedAt === 0) await updateSettings({ ...DEFAULT_SETTINGS, updatedAt: Date.now() });
}

async function rescheduleAlarm() {
  const s = await getSettings();
  const minutes = Math.max(5, s.syncIntervalMinutes || 15);
  await chrome.alarms.clear(SYNC_ALARM);
  await chrome.alarms.create(SYNC_ALARM, {
    delayInMinutes: 1,
    periodInMinutes: minutes,
  });
}

// ---------------------------------------------------------------------------
// Alarm handler
// ---------------------------------------------------------------------------

chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== SYNC_ALARM) return;
  try {
    await syncFromMeta();
  } catch (e) {
    console.error("[sync] failed", e);
    notifyError("LeadLoom sync failed", (e as Error).message);
  }
});

async function syncFromMeta() {
  const s = await getSettings();
  if (!s.metaAccessToken || s.metaPageIds.length === 0) return; // not configured yet

  for (const pageId of s.metaPageIds) {
    // 1. Lead Ads forms → leads.
    try {
      const forms = await listForms(pageId, s.metaAccessToken);
      for (const form of forms) {
        const raws = await fetchFormLeads(form.id, s.metaAccessToken);
        for (const raw of raws) {
          const candidate = toCrmLead(raw, { pageId, formName: form.name });
          if (await isDuplicate(candidate)) continue;
          const saved = await upsertLead(candidate);
          await maybeScoreAndNotify(saved);
        }
      }
    } catch (e) {
      console.warn(`[sync] Lead Ads on ${pageId} failed`, e);
    }

    // 2. Public mentions of the Page.
    try {
      const mentions = await fetchPageMentions(pageId, s.metaAccessToken);
      const keywords = await listKeywords();
      for (const m of mentions) {
        const text = m.message ?? "";
        const matched = matchKeywords(text, keywords);
        const candidate = {
          name: m.from?.name ?? "Unknown",
          profileUrl: m.from?.id ? `https://www.facebook.com/${m.from.id}` : undefined,
          postContent: text,
          postUrl: m.permalink_url,
          postCreatedAt: new Date(m.created_time).getTime(),
          source: "page_mention" as const,
          matchedKeywords: matched,
          stage: "new" as const,
          temperature: "cold" as const,
          score: 0,
          tags: ["page_mention"],
          archived: false,
        };
        if (await isDuplicate(candidate)) continue;
        const saved = await upsertLead(candidate);
        await maybeScoreAndNotify(saved);
      }
    } catch (e) {
      console.warn(`[sync] Mentions on ${pageId} failed`, e);
    }
  }
}

async function maybeScoreAndNotify(lead: Lead) {
  const s = await getSettings();
  const scored = await scoreLead(lead, s);
  if (s.notifyOnHot && scored.temperature === "hot") notifyHotLead(scored);
}

// ---------------------------------------------------------------------------
// Message router
// ---------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((msg: RuntimeMessage, _sender, sendResponse) => {
  // Wrap in async IIFE so we can `return true` synchronously to keep the port open.
  (async () => {
    try {
      const data = await handle(msg);
      sendResponse({ ok: true, data } satisfies RuntimeResponse);
    } catch (e) {
      console.error("[router]", msg.type, e);
      sendResponse({ ok: false, error: (e as Error).message } satisfies RuntimeResponse);
    }
  })();
  return true;
});

async function handle(msg: RuntimeMessage): Promise<unknown> {
  switch (msg.type) {
    case "lead:save": {
      if (await isDuplicate(msg.payload)) {
        return { duplicate: true };
      }
      const saved = await upsertLead(msg.payload);
      const s = await getSettings();
      const scored = await scoreLead(saved, s);
      if (s.notifyOnHot && scored.temperature === "hot") notifyHotLead(scored);
      return scored;
    }
    case "lead:score": {
      const lead = await getLead(msg.payload.leadId);
      if (!lead) throw new Error("Lead not found");
      const s = await getSettings();
      return scoreLead(lead, s);
    }
    case "lead:list": {
      return listLeads({ stage: msg.payload?.stage });
    }
    case "settings:get": {
      return getSettings();
    }
    case "settings:update": {
      const next = await updateSettings(msg.payload);
      await rescheduleAlarm();
      return next;
    }
    case "sync:metaLeadAds": {
      await syncFromMeta();
      return { ok: true };
    }
    case "ai:draftMessage": {
      const lead = await getLead(msg.payload.leadId);
      if (!lead) throw new Error("Lead not found");
      const s = await getSettings();
      const tone = msg.payload.tone ?? s.defaultTone;
      const drafted = await draftMessage(lead, tone, {
        anthropic: s.anthropicApiKey,
        openai: s.openaiApiKey,
      });
      await logOutreach({ leadId: lead.id, body: drafted.body, action: "drafted" });
      return drafted;
    }
    case "ai:scoreText": {
      const s = await getSettings();
      const { scoreIntent } = await import("@lib/api/ai");
      return scoreIntent(msg.payload.text, {
        anthropic: s.anthropicApiKey,
        openai: s.openaiApiKey,
      });
    }
  }
}

// Keep the DB reference alive in case the worker is woken up by something
// other than a message (e.g. an alarm). Reading triggers Dexie's open().
db.leads.count().catch(() => void 0);

// Re-export helpers used elsewhere (for typing).
export type { RuntimeMessage };
// Intentionally unused-imports to keep tree-shaker honest:
void deleteLead;
void archiveLead;
void setStage;
