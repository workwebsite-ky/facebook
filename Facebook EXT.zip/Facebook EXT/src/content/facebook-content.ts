/**
 * Content script — manual "Save as Lead" helper.
 *
 * IMPORTANT: This script does NOT scrape Facebook. It does NOT crawl posts,
 * walk search results, send mass messages, or evade rate limits. It only
 * injects a small floating button that lets the user manually capture the
 * post they are currently viewing into the CRM.
 *
 * Capture flow:
 *   user clicks button → script reads the post URL from the address bar +
 *   the selected text (if any) → sends a `lead:save` message to the worker.
 *
 * We intentionally rely on the user's selection / address bar instead of
 * walking the DOM, so we never collect data the user didn't actively choose
 * to capture, and we don't break when Facebook ships a UI change.
 */

import type { RuntimeMessage, RuntimeResponse } from "@types/index";

const BTN_ID = "leadloom-save-btn";

function isPostLikeUrl(href: string): boolean {
  return /facebook\.com\/(.+?\/posts\/|.+?\/videos\/|story\.php|share\/p\/|groups\/.+\/permalink\/)/.test(
    href,
  );
}

function ensureButton() {
  if (document.getElementById(BTN_ID)) return;
  const btn = document.createElement("button");
  btn.id = BTN_ID;
  btn.type = "button";
  btn.textContent = "Save lead";
  btn.title = "LeadLoom — capture this post as a lead";
  btn.setAttribute("aria-label", "Save as lead in LeadLoom");
  btn.addEventListener("click", onClick);
  document.documentElement.appendChild(btn);
}

function removeButton() {
  document.getElementById(BTN_ID)?.remove();
}

async function onClick() {
  const selection = window.getSelection()?.toString().trim() ?? "";
  const url = window.location.href;
  // Best-effort: pull a name from the document title (the post author).
  const title = document.title.replace(/\s*\|\s*Facebook.*$/i, "").trim();
  const author = title.split(/[-—]/)[0]?.trim() || "Unknown";

  const payload: RuntimeMessage = {
    type: "lead:save",
    payload: {
      name: author,
      postUrl: url,
      profileUrl: undefined,
      postContent: selection || undefined,
      matchedKeywords: [],
      source: "manual_save",
      postCreatedAt: Date.now(),
      tags: ["manual"],
    },
  };

  try {
    const res: RuntimeResponse<any> = await chrome.runtime.sendMessage(payload);
    if (!res?.ok) {
      flash(`Save failed: ${res?.error ?? "unknown error"}`, "error");
      return;
    }
    if (res.data?.duplicate) flash("Already saved", "info");
    else flash(`Saved as ${res.data?.temperature ?? ""} lead`, "ok");
  } catch (e) {
    flash(`Save failed: ${(e as Error).message}`, "error");
  }
}

function flash(text: string, kind: "ok" | "error" | "info") {
  const el = document.createElement("div");
  el.className = `leadloom-toast leadloom-toast-${kind}`;
  el.textContent = text;
  document.documentElement.appendChild(el);
  setTimeout(() => el.remove(), 2400);
}

function refresh() {
  if (isPostLikeUrl(window.location.href)) ensureButton();
  else removeButton();
}

// Watch for SPA navigation — Facebook is a single-page app.
let lastHref = window.location.href;
const observer = new MutationObserver(() => {
  if (window.location.href !== lastHref) {
    lastHref = window.location.href;
    refresh();
  }
});
observer.observe(document.documentElement, { childList: true, subtree: true });

refresh();
