/**
 * Compact popup shown when the user clicks the toolbar icon.
 * Quick stats + the 5 most recent leads + a button to open the full dashboard.
 */

import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ExternalLink, Flame, Search, Settings as SettingsIcon } from "lucide-react";
import { db } from "@lib/db/schema";
import { analyticsSummary } from "@lib/db";
import { timeAgo, truncate } from "@lib/utils";
import type { Lead } from "@types/index";

export function Popup() {
  const recent = useLiveQuery<Lead[]>(
    () => db.leads.orderBy("createdAt").reverse().limit(5).toArray(),
    [],
    [] as Lead[],
  );

  const [summary, setSummary] = useState<{ total: number; byTemperature: Record<string, number> }>({
    total: 0,
    byTemperature: { hot: 0, warm: 0, cold: 0 },
  });

  useEffect(() => {
    analyticsSummary().then((s) => setSummary({ total: s.total, byTemperature: s.byTemperature }));
  }, [recent?.length]);

  const open = (hash = "") => {
    chrome.tabs.create({ url: chrome.runtime.getURL(`src/dashboard/index.html${hash}`) });
  };

  return (
    <div className="flex flex-col h-full">
      <header className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md bg-accent text-white grid place-items-center text-xs font-bold">
            LL
          </div>
          <span className="font-semibold">LeadLoom</span>
        </div>
        <button
          onClick={() => open("#/settings")}
          className="p-1.5 rounded-md hover:bg-bg-hover text-text-muted"
          title="Settings"
        >
          <SettingsIcon size={16} />
        </button>
      </header>

      <section className="grid grid-cols-3 gap-2 px-4 py-3">
        <Stat label="Total" value={summary.total} />
        <Stat label="Hot" value={summary.byTemperature.hot ?? 0} accent="hot" />
        <Stat label="Warm" value={summary.byTemperature.warm ?? 0} accent="warm" />
      </section>

      <section className="px-4 pb-2">
        <div className="flex items-center justify-between text-xs uppercase tracking-wide text-text-faint">
          <span>Recent leads</span>
          <button onClick={() => open()} className="text-accent hover:underline normal-case tracking-normal">
            View all →
          </button>
        </div>
      </section>

      <div className="flex-1 overflow-y-auto px-2 pb-2">
        {!recent?.length ? (
          <Empty />
        ) : (
          <ul className="space-y-1">
            {recent.map((l) => (
              <li
                key={l.id}
                className="px-3 py-2 rounded-md hover:bg-bg-hover cursor-pointer"
                onClick={() => open(`#/leads/${l.id}`)}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium text-sm truncate">{l.name}</span>
                  <TempPill t={l.temperature} />
                </div>
                <div className="text-xs text-text-muted truncate">{truncate(l.postContent ?? "", 80)}</div>
                <div className="text-[10px] text-text-faint mt-0.5">{timeAgo(l.createdAt)}</div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <footer className="border-t border-border p-2 grid grid-cols-2 gap-2">
        <button
          onClick={() => open("#/leads")}
          className="flex items-center justify-center gap-1.5 text-xs py-2 rounded-md bg-bg-hover hover:bg-bg-muted"
        >
          <Search size={14} /> Leads
        </button>
        <button
          onClick={() => open("#/leads?temp=hot")}
          className="flex items-center justify-center gap-1.5 text-xs py-2 rounded-md bg-hot text-white hover:opacity-90"
        >
          <Flame size={14} /> Hot only
        </button>
      </footer>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: number; accent?: "hot" | "warm" }) {
  const color =
    accent === "hot" ? "text-hot" : accent === "warm" ? "text-warm" : "text-text";
  return (
    <div className="rounded-md border border-border px-2.5 py-2">
      <div className={`text-lg font-semibold ${color}`}>{value}</div>
      <div className="text-[10px] uppercase tracking-wide text-text-faint">{label}</div>
    </div>
  );
}

function TempPill({ t }: { t: Lead["temperature"] }) {
  const cls =
    t === "hot"
      ? "bg-hot/10 text-hot"
      : t === "warm"
        ? "bg-warm/10 text-warm"
        : "bg-cold/10 text-cold";
  return <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${cls}`}>{t}</span>;
}

function Empty() {
  return (
    <div className="p-6 text-center text-sm text-text-muted">
      <p className="font-medium text-text">No leads yet</p>
      <p className="mt-1">
        Browse Facebook and click <span className="font-semibold">Save lead</span> on a post, or connect Meta
        Lead Ads in settings.
      </p>
      <a
        className="inline-flex items-center gap-1 text-accent mt-3 hover:underline"
        href="https://www.facebook.com"
        target="_blank"
        rel="noreferrer"
      >
        Open Facebook <ExternalLink size={12} />
      </a>
    </div>
  );
}
