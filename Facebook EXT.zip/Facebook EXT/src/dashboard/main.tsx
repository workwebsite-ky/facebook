import React from "react";
import { createRoot } from "react-dom/client";
import { HashRouter } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { App } from "./App";

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <HashRouter>
      <App />
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: "rgb(var(--bg-subtle))",
            color: "rgb(var(--text))",
            border: "1px solid rgb(var(--border))",
          },
        }}
      />
    </HashRouter>
  </React.StrictMode>,
);
