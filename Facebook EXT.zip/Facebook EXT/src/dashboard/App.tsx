import { Navigate, Route, Routes } from "react-router-dom";
import { Sidebar } from "./components/Sidebar";
import { Leads } from "./pages/Leads";
import { Keywords } from "./pages/Keywords";
import { Templates } from "./pages/Templates";
import { Analytics } from "./pages/Analytics";
import { Settings } from "./pages/Settings";
import { useTheme } from "./hooks/useTheme";

export function App() {
  useTheme(); // applies .dark class based on Settings.theme

  return (
    <div className="flex h-full">
      <Sidebar />
      <main className="flex-1 min-w-0 overflow-y-auto">
        <Routes>
          <Route path="/" element={<Navigate to="/leads" replace />} />
          <Route path="/leads" element={<Leads />} />
          <Route path="/leads/:id" element={<Leads />} />
          <Route path="/keywords" element={<Keywords />} />
          <Route path="/templates" element={<Templates />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/leads" replace />} />
        </Routes>
      </main>
    </div>
  );
}
