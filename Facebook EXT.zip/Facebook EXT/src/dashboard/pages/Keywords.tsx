import { useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Plus, Trash2 } from "lucide-react";
import toast from "react-hot-toast";
import { db } from "@lib/db/schema";
import { deleteKeyword, upsertKeyword } from "@lib/db";
import { cn, timeAgo } from "@lib/utils";

export function Keywords() {
  const keywords = useLiveQuery(() => db.keywords.orderBy("createdAt").reverse().toArray(), [], []);
  const [phrase, setPhrase] = useState("");

  async function add() {
    const p = phrase.trim();
    if (!p) return;
    await upsertKeyword({ phrase: p });
    setPhrase("");
    toast.success("Keyword added");
  }

  async function bulkPaste() {
    const text = prompt("Paste one keyword per line");
    if (!text) return;
    const lines = text.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    for (const line of lines) await upsertKeyword({ phrase: line });
    toast.success(`Added ${lines.length} keywords`);
  }

  return (
    <div className="p-6 space-y-4 max-w-3xl">
      <header>
        <h1 className="text-xl font-semibold">Keywords</h1>
        <p className="text-sm text-text-faint">
          Words to watch for in Lead Ads submissions, Page mentions, and manually saved posts.
          These are <em>matched against incoming text</em>; LeadLoom does not search Facebook on
          your behalf.
        </p>
      </header>

      <div className="card p-3 flex items-center gap-2">
        <input
          className="input flex-1"
          placeholder="e.g. need website"
          value={phrase}
          onChange={(e) => setPhrase(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && add()}
        />
        <button onClick={add} className="btn btn-primary">
          <Plus size={14} /> Add
        </button>
        <button onClick={bulkPaste} className="btn">Bulk paste</button>
      </div>

      <div className="card divide-y divide-border">
        {keywords?.length === 0 && (
          <div className="p-6 text-sm text-text-muted text-center">No keywords yet.</div>
        )}
        {keywords?.map((k) => (
          <div key={k.id} className="flex items-center gap-3 px-4 py-2.5">
            <button
              onClick={() => upsertKeyword({ ...k, active: !k.active })}
              className={cn(
                "w-9 h-5 rounded-full relative transition-colors",
                k.active ? "bg-accent" : "bg-bg-muted",
              )}
              title={k.active ? "Active" : "Paused"}
            >
              <span
                className={cn(
                  "absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all",
                  k.active ? "left-4" : "left-0.5",
                )}
              />
            </button>
            <div className="flex-1 min-w-0">
              <div className="font-medium">{k.phrase}</div>
              <div className="text-xs text-text-faint">
                {k.lastUsedAt ? `Last matched ${timeAgo(k.lastUsedAt)}` : "Never matched yet"}
              </div>
            </div>
            <button
              onClick={() => deleteKeyword(k.id)}
              className="btn btn-ghost text-rose-600 p-1.5"
            >
              <Trash2 size={14} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
