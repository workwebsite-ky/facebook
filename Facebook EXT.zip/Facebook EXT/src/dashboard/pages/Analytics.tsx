import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "@lib/db/schema";
import { analyticsSummary } from "@lib/db";
import type { Lead } from "@types/index";

interface Summary {
  total: number;
  byStage: Record<string, number>;
  byTemperature: Record<string, number>;
  avgScore: number;
}

export function Analytics() {
  const leads = useLiveQuery<Lead[]>(() => db.leads.toArray(), [], []);
  const [s, setS] = useState<Summary>({
    total: 0,
    byStage: {},
    byTemperature: { hot: 0, warm: 0, cold: 0 },
    avgScore: 0,
  });

  useEffect(() => {
    analyticsSummary().then(setS);
  }, [leads?.length]);

  return (
    <div className="p-6 space-y-6 max-w-5xl">
      <header>
        <h1 className="text-xl font-semibold">Analytics</h1>
        <p className="text-sm text-text-faint">Aggregate view of your pipeline.</p>
      </header>

      <div className="grid grid-cols-4 gap-3">
        <Tile label="Total leads" value={s.total} />
        <Tile label="Hot" value={s.byTemperature.hot ?? 0} accent="hot" />
        <Tile label="Warm" value={s.byTemperature.warm ?? 0} accent="warm" />
        <Tile label="Avg score" value={s.avgScore} suffix="/100" />
      </div>

      <section className="card p-5">
        <h2 className="font-semibold mb-3">By stage</h2>
        <ul className="space-y-2">
          {Object.entries(s.byStage).map(([stage, count]) => (
            <li key={stage} className="flex items-center gap-3">
              <span className="w-32 text-sm capitalize text-text-muted">{stage.replace("_", " ")}</span>
              <div className="flex-1 h-2 rounded-full bg-bg-muted overflow-hidden">
                <div
                  className="h-full bg-accent"
                  style={{ width: s.total ? `${(count / s.total) * 100}%` : "0%" }}
                />
              </div>
              <span className="text-sm tabular-nums w-10 text-right">{count}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="card p-5">
        <h2 className="font-semibold mb-3">By temperature</h2>
        <div className="grid grid-cols-3 gap-3">
          {(["hot", "warm", "cold"] as const).map((t) => (
            <div key={t} className="text-center py-4 rounded-md bg-bg-muted">
              <div className={`text-2xl font-bold ${t === "hot" ? "text-hot" : t === "warm" ? "text-warm" : "text-cold"}`}>
                {s.byTemperature[t] ?? 0}
              </div>
              <div className="text-xs uppercase tracking-wide text-text-faint mt-1">{t}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Tile({ label, value, suffix, accent }: { label: string; value: number; suffix?: string; accent?: "hot" | "warm" }) {
  const color = accent === "hot" ? "text-hot" : accent === "warm" ? "text-warm" : "text-text";
  return (
    <div className="card p-4">
      <div className={`text-2xl font-semibold ${color}`}>
        {value}
        {suffix && <span className="text-base text-text-faint font-normal">{suffix}</span>}
      </div>
      <div className="text-xs uppercase tracking-wide text-text-faint mt-1">{label}</div>
    </div>
  );
}
