import { useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { Plus, RefreshCw } from "lucide-react";
import toast from "react-hot-toast";
import { db } from "@lib/db/schema";
import { upsertLead } from "@lib/db";
import { LeadFilters, applyFilters, type LeadFilterState } from "../components/LeadFilters";
import { LeadTable } from "../components/LeadTable";
import { LeadDrawer } from "../components/LeadDrawer";
import { ExportMenu } from "../components/ExportMenu";
import { send } from "../hooks/useRuntime";
import type { Lead } from "@types/index";

export function Leads() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [searchParams] = useSearchParams();

  const initialFilters: LeadFilterState = {
    query: "",
    stage: "all",
    temperature: (searchParams.get("temp") as LeadFilterState["temperature"]) ?? "all",
    minScore: 0,
    source: "all",
    recency: "all",
  };
  const [filters, setFilters] = useState<LeadFilterState>(initialFilters);

  const leads = useLiveQuery<Lead[]>(
    () => db.leads.orderBy("createdAt").reverse().toArray(),
    [],
    [] as Lead[],
  );

  const filtered = useMemo(() => applyFilters(leads ?? [], filters), [leads, filters]);

  async function manualSync() {
    const t = toast.loading("Syncing from Meta…");
    try {
      await send({ type: "sync:metaLeadAds" });
      toast.success("Sync complete", { id: t });
    } catch (e) {
      toast.error((e as Error).message, { id: t });
    }
  }

  async function addManual() {
    const name = prompt("Lead name");
    if (!name) return;
    const post = prompt("Their need / message (optional)") ?? "";
    const saved = await upsertLead({
      name,
      postContent: post,
      source: "manual_entry",
      matchedKeywords: [],
      stage: "new",
      temperature: "cold",
      score: 0,
      tags: [],
      archived: false,
    });
    navigate(`/leads/${saved.id}`);
  }

  return (
    <div className="p-6 space-y-4">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Leads</h1>
          <p className="text-sm text-text-faint">
            {filtered.length} of {leads?.length ?? 0} • showing live results
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={manualSync} className="btn">
            <RefreshCw size={14} /> Sync Meta
          </button>
          <ExportMenu rows={filtered} />
          <button onClick={addManual} className="btn btn-primary">
            <Plus size={14} /> Add lead
          </button>
        </div>
      </header>

      <LeadFilters value={filters} onChange={setFilters} />

      <LeadTable
        rows={filtered}
        selectedId={id}
        onOpen={(l) => navigate(`/leads/${l.id}`)}
      />

      <LeadDrawer leadId={id ?? null} onClose={() => navigate("/leads")} />
    </div>
  );
}
