import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { getSettings, updateSettings } from "@lib/db";
import type { Settings as SettingsT } from "@types/index";
import { listPages, type MetaPage } from "@lib/api/meta";

export function Settings() {
  const [s, setS] = useState<SettingsT | null>(null);
  const [pages, setPages] = useState<MetaPage[]>([]);
  const [loadingPages, setLoadingPages] = useState(false);

  useEffect(() => {
    getSettings().then(setS);
  }, []);

  async function save<K extends keyof SettingsT>(key: K, value: SettingsT[K]) {
    const next = await updateSettings({ [key]: value } as Partial<SettingsT>);
    setS(next);
  }

  async function loadPages() {
    if (!s?.metaAccessToken) return;
    setLoadingPages(true);
    try {
      const list = await listPages(s.metaAccessToken);
      setPages(list);
      toast.success(`Found ${list.length} Pages`);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoadingPages(false);
    }
  }

  if (!s) return <div className="p-6">Loading…</div>;

  return (
    <div className="p-6 max-w-3xl space-y-8">
      <header>
        <h1 className="text-xl font-semibold">Settings</h1>
        <p className="text-sm text-text-faint">
          API keys and tokens live in <code>chrome.storage.local</code> and never leave your machine
          except to talk to the providers directly.
        </p>
      </header>

      <Section title="AI providers" description="Claude is preferred; OpenAI is a fallback. At least one is recommended.">
        <Field label="Anthropic API key">
          <input
            type="password"
            className="input"
            value={s.anthropicApiKey ?? ""}
            onChange={(e) => save("anthropicApiKey", e.target.value)}
            placeholder="sk-ant-…"
          />
        </Field>
        <Field label="OpenAI API key (optional)">
          <input
            type="password"
            className="input"
            value={s.openaiApiKey ?? ""}
            onChange={(e) => save("openaiApiKey", e.target.value)}
            placeholder="sk-…"
          />
        </Field>
        <Field label="Default tone">
          <select
            className="input"
            value={s.defaultTone}
            onChange={(e) => save("defaultTone", e.target.value as SettingsT["defaultTone"])}
          >
            <option value="friendly">Friendly</option>
            <option value="professional">Professional</option>
            <option value="casual">Casual</option>
            <option value="direct">Direct</option>
          </select>
        </Field>
      </Section>

      <Section
        title="Meta Lead Ads"
        description="Connects to the official Graph API. Generate a long-lived Page access token following docs/API_INTEGRATION.md."
      >
        <Field label="Meta access token">
          <input
            type="password"
            className="input"
            value={s.metaAccessToken ?? ""}
            onChange={(e) => save("metaAccessToken", e.target.value)}
            placeholder="EAAB…"
          />
        </Field>
        <button onClick={loadPages} disabled={!s.metaAccessToken || loadingPages} className="btn">
          {loadingPages ? "Loading…" : "Fetch my Pages"}
        </button>
        {pages.length > 0 && (
          <div className="card p-3 mt-3">
            <p className="text-xs text-text-faint mb-2">Select which Pages to sync leads from:</p>
            <ul className="space-y-1">
              {pages.map((p) => {
                const checked = s.metaPageIds.includes(p.id);
                return (
                  <li key={p.id}>
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(e) => {
                          const next = e.target.checked
                            ? [...s.metaPageIds, p.id]
                            : s.metaPageIds.filter((id) => id !== p.id);
                          save("metaPageIds", next);
                        }}
                      />
                      {p.name} <span className="text-text-faint text-xs">({p.id})</span>
                    </label>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
        <Field label="Sync interval (minutes)">
          <input
            type="number"
            className="input w-32"
            min={5}
            max={1440}
            value={s.syncIntervalMinutes}
            onChange={(e) => save("syncIntervalMinutes", Math.max(5, Number(e.target.value) || 15))}
          />
        </Field>
      </Section>

      <Section title="Notifications & filters">
        <Toggle
          label="Notify me when a hot lead arrives"
          value={s.notifyOnHot}
          onChange={(v) => save("notifyOnHot", v)}
        />
        <Field label="Default minimum score">
          <input
            type="number"
            min={0}
            max={100}
            className="input w-32"
            value={s.minScoreFilter}
            onChange={(e) => save("minScoreFilter", Math.max(0, Math.min(100, Number(e.target.value) || 0)))}
          />
        </Field>
      </Section>

      <Section title="Appearance">
        <Field label="Theme">
          <select
            className="input"
            value={s.theme}
            onChange={(e) => save("theme", e.target.value as SettingsT["theme"])}
          >
            <option value="system">System</option>
            <option value="light">Light</option>
            <option value="dark">Dark</option>
          </select>
        </Field>
        <Field label="Density">
          <select
            className="input"
            value={s.density}
            onChange={(e) => save("density", e.target.value as SettingsT["density"])}
          >
            <option value="comfortable">Comfortable</option>
            <option value="compact">Compact</option>
          </select>
        </Field>
      </Section>
    </div>
  );
}

function Section({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <section className="space-y-3">
      <div>
        <h2 className="font-semibold">{title}</h2>
        {description && <p className="text-xs text-text-faint mt-0.5">{description}</p>}
      </div>
      <div className="space-y-3">{children}</div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs text-text-muted mb-1 block">{label}</span>
      {children}
    </label>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center gap-3 cursor-pointer">
      <button
        type="button"
        onClick={() => onChange(!value)}
        className={`w-10 h-5 rounded-full relative ${value ? "bg-accent" : "bg-bg-muted"}`}
      >
        <span
          className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${value ? "left-5" : "left-0.5"}`}
        />
      </button>
      <span className="text-sm">{label}</span>
    </label>
  );
}
