import { useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Plus, Trash2 } from "lucide-react";
import toast from "react-hot-toast";
import { db } from "@lib/db/schema";
import { deleteTemplate, upsertTemplate } from "@lib/db";
import type { MessageTemplate } from "@types/index";

export function Templates() {
  const templates = useLiveQuery<MessageTemplate[]>(
    () => db.templates.orderBy("updatedAt").reverse().toArray(),
    [],
    [],
  );
  const [editing, setEditing] = useState<MessageTemplate | null>(null);

  function startNew() {
    setEditing({
      id: "",
      name: "Untitled",
      body: "Hey {{name}}, ",
      tags: [],
      tone: "friendly",
      createdAt: 0,
      updatedAt: 0,
    });
  }

  async function save() {
    if (!editing) return;
    const saved = await upsertTemplate({
      id: editing.id || undefined,
      name: editing.name,
      body: editing.body,
      tags: editing.tags,
      tone: editing.tone,
    } as any);
    setEditing(saved);
    toast.success("Saved");
  }

  return (
    <div className="p-6 grid grid-cols-[280px_1fr] gap-6 h-[calc(100vh-0px)]">
      <aside className="card overflow-hidden flex flex-col">
        <div className="p-3 border-b border-border flex items-center justify-between">
          <h2 className="font-semibold text-sm">Templates</h2>
          <button onClick={startNew} className="btn btn-primary py-1 px-2 text-xs">
            <Plus size={12} /> New
          </button>
        </div>
        <ul className="overflow-y-auto">
          {templates?.map((t) => (
            <li
              key={t.id}
              onClick={() => setEditing(t)}
              className={`px-3 py-2 cursor-pointer hover:bg-bg-hover border-b border-border ${editing?.id === t.id ? "bg-bg-hover" : ""}`}
            >
              <div className="font-medium text-sm">{t.name}</div>
              <div className="text-xs text-text-faint capitalize">{t.tone}</div>
            </li>
          ))}
        </ul>
      </aside>

      <section className="card p-5 overflow-y-auto">
        {!editing ? (
          <div className="text-center text-text-muted py-20">
            Select a template or click <span className="font-semibold">New</span>.
          </div>
        ) : (
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-2">
              <input
                className="input flex-1 font-semibold text-base"
                value={editing.name}
                onChange={(e) => setEditing({ ...editing, name: e.target.value })}
              />
              <select
                className="input w-36"
                value={editing.tone}
                onChange={(e) => setEditing({ ...editing, tone: e.target.value as MessageTemplate["tone"] })}
              >
                <option value="friendly">Friendly</option>
                <option value="professional">Professional</option>
                <option value="casual">Casual</option>
                <option value="direct">Direct</option>
              </select>
            </div>

            <textarea
              className="input min-h-[260px] font-sans leading-relaxed"
              value={editing.body}
              onChange={(e) => setEditing({ ...editing, body: e.target.value })}
              placeholder="Use {{name}}, {{keyword}}, {{service}} as placeholders."
            />

            <input
              className="input"
              placeholder="tags, comma separated"
              value={editing.tags.join(", ")}
              onChange={(e) =>
                setEditing({ ...editing, tags: e.target.value.split(",").map((t) => t.trim()).filter(Boolean) })
              }
            />

            <div className="flex items-center justify-between pt-2">
              <button onClick={save} className="btn btn-primary">Save</button>
              {editing.id && (
                <button
                  onClick={() => {
                    if (confirm("Delete this template?")) {
                      deleteTemplate(editing.id).then(() => setEditing(null));
                    }
                  }}
                  className="btn text-rose-600"
                >
                  <Trash2 size={14} /> Delete
                </button>
              )}
            </div>

            <div className="text-xs text-text-faint pt-4 border-t border-border mt-4">
              Supported placeholders: {`{{name}}`}, {`{{keyword}}`}, {`{{service}}`}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
