import { useEffect } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "@lib/db/schema";

export function useTheme() {
  const settings = useLiveQuery(() => db.settings.get("default"), [], undefined);

  useEffect(() => {
    const theme = settings?.theme ?? "system";
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const dark = theme === "dark" || (theme === "system" && prefersDark);
    document.documentElement.classList.toggle("dark", dark);
  }, [settings?.theme]);
}
