/**
 * Thin wrapper around chrome.runtime.sendMessage with typed payloads.
 */

import type { RuntimeMessage, RuntimeResponse } from "@types/index";

export async function send<T = unknown>(msg: RuntimeMessage): Promise<T> {
  const res = (await chrome.runtime.sendMessage(msg)) as RuntimeResponse<T> | undefined;
  if (!res?.ok) throw new Error(res?.error ?? "Unknown error from service worker");
  return res.data as T;
}
