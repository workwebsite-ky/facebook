import { ArrowUpRight, Flame, Snowflake, Sun } from "lucide-react";
import { cn, timeAgo, truncate } from "@lib/utils";
import type { Lead, LeadTemperature } from "@types/index";

export function LeadTable({
  rows,
  onOpen,
  selectedId,
}: {
  rows: Lead[];
  onOpen: (l: Lead) => void;
  selectedId?: string;
}) {
  if (!rows.length) {
    return (
      <div className="card p-10 text-center text-sm text-text-muted">
        <p className="font-medium text-text">No leads match these filters.</p>
        <p className="mt-1">Try widening the time range or lowering the minimum score.</p>
      </div>
    );
  }

  return (
    <div className="card overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-bg-muted text-text-muted text-xs uppercase tracking-wide">
          <tr>
            <Th>Name</Th>
            <Th>Post / message</Th>
            <Th>Keywords</Th>
            <Th>Stage</Th>
            <Th>Temp</Th>
            <Th>Score</Th>
            <Th>When</Th>
            <Th></Th>
          </tr>
        </thead>
        <tbody>
          {rows.map((l) => (
            <tr
              key={l.id}
              onClick={() => onOpen(l)}
              className={cn(
                "border-t border-border hover:bg-bg-hover cursor-pointer",
                selectedId === l.id && "bg-bg-hover",
              )}
            >
              <Td>
                <div className="font-medium">{l.name}</div>
                <div className="text-[11px] text-text-faint">{l.source}</div>
              </Td>
              <Td>
                <div className="max-w-[420px] truncate text-text-muted">
                  {truncate(l.postContent ?? "", 110)}
                </div>
              </Td>
              <Td>
                <div className="flex flex-wrap gap-1">
                  {l.matchedKeywords.slice(0, 2).map((k) => (
                    <span key={k} className="pill bg-bg-muted text-text-muted">
                      {k}
                    </span>
                  ))}
                  {l.matchedKeywords.length > 2 && (
                    <span className="pill bg-bg-muted text-text-faint">+{l.matchedKeywords.length - 2}</span>
                  )}
                </div>
              </Td>
              <Td>
                <StagePill stage={l.stage} />
              </Td>
              <Td>
                <TempBadge t={l.temperature} />
              </Td>
              <Td>
                <ScoreBar score={l.score} />
              </Td>
              <Td className="text-text-faint whitespace-nowrap">
                {timeAgo(l.postCreatedAt ?? l.createdAt)}
              </Td>
              <Td className="text-right">
                <ArrowUpRight size={14} className="text-text-faint" />
              </Td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="text-left px-3 py-2 font-medium">{children}</th>;
}
function Td({ children, className }: { children: React.ReactNode; className?: string }) {
  return <td className={cn("px-3 py-2 align-top", className)}>{children}</td>;
}

function StagePill({ stage }: { stage: Lead["stage"] }) {
  const map: Record<Lead["stage"], string> = {
    new: "bg-bg-muted text-text-muted",
    contacted: "bg-cold/10 text-cold",
    replied: "bg-warm/10 text-warm",
    interested: "bg-accent/10 text-accent",
    closed_won: "bg-emerald-500/10 text-emerald-600",
    closed_lost: "bg-rose-500/10 text-rose-600",
  };
  return <span className={cn("pill", map[stage])}>{stage.replace("_", " ")}</span>;
}

function TempBadge({ t }: { t: LeadTemperature }) {
  const Icon = t === "hot" ? Flame : t === "warm" ? Sun : Snowflake;
  const cls = t === "hot" ? "text-hot" : t === "warm" ? "text-warm" : "text-cold";
  return (
    <span className={cn("inline-flex items-center gap-1 text-xs font-medium", cls)}>
      <Icon size={12} /> {t}
    </span>
  );
}

function ScoreBar({ score }: { score: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="w-16 h-1.5 rounded-full bg-bg-muted overflow-hidden">
        <div
          className={cn(
            "h-full",
            score >= 70 ? "bg-hot" : score >= 40 ? "bg-warm" : "bg-cold",
          )}
          style={{ width: `${score}%` }}
        />
      </div>
      <span className="text-xs text-text-muted tabular-nums w-7 text-right">{score}</span>
    </div>
  );
}
