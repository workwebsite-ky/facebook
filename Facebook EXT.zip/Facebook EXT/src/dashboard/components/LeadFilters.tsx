import { Search } from "lucide-react";
import { LEAD_STAGES, type LeadStage, type LeadTemperature } from "@types/index";

export interface LeadFilterState {
  query: string;
  stage: LeadStage | "all";
  temperature: LeadTemperature | "all";
  minScore: number;
  source: "all" | "lead_ads" | "page_mention" | "manual_save" | "csv_import" | "manual_entry";
  recency: "all" | "1h" | "3h" | "6h" | "12h" | "24h" | "7d";
}

export function LeadFilters({
  value,
  onChange,
}: {
  value: LeadFilterState;
  onChange: (v: LeadFilterState) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="relative flex-1 min-w-[220px]">
        <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-text-faint" />
        <input
          className="input pl-8"
          placeholder="Search name, post, keyword…"
          value={value.query}
          onChange={(e) => onChange({ ...value, query: e.target.value })}
        />
      </div>

      <Select
        label="Stage"
        value={value.stage}
        onChange={(v) => onChange({ ...value, stage: v as LeadFilterState["stage"] })}
        options={[{ value: "all", label: "All stages" }, ...LEAD_STAGES.map((s) => ({ value: s, label: s }))]}
      />

      <Select
        label="Temp"
        value={value.temperature}
        onChange={(v) => onChange({ ...value, temperature: v as LeadFilterState["temperature"] })}
        options={[
          { value: "all", label: "Any temp" },
          { value: "hot", label: "Hot" },
          { value: "warm", label: "Warm" },
          { value: "cold", label: "Cold" },
        ]}
      />

      <Select
        label="Source"
        value={value.source}
        onChange={(v) => onChange({ ...value, source: v as LeadFilterState["source"] })}
        options={[
          { value: "all", label: "Any source" },
          { value: "lead_ads", label: "Lead Ads" },
          { value: "page_mention", label: "Page mention" },
          { value: "manual_save", label: "Manual save" },
          { value: "csv_import", label: "CSV import" },
          { value: "manual_entry", label: "Manual entry" },
        ]}
      />

      <Select
        label="Recency"
        value={value.recency}
        onChange={(v) => onChange({ ...value, recency: v as LeadFilterState["recency"] })}
        options={[
          { value: "all", label: "Any time" },
          { value: "1h", label: "Last 1h" },
          { value: "3h", label: "Last 3h" },
          { value: "6h", label: "Last 6h" },
          { value: "12h", label: "Last 12h" },
          { value: "24h", label: "Last 24h" },
          { value: "7d", label: "Last 7d" },
        ]}
      />

      <label className="flex items-center gap-1.5 text-xs text-text-muted">
        Score ≥
        <input
          type="number"
          min={0}
          max={100}
          className="input w-16 py-1 text-center"
          value={value.minScore}
          onChange={(e) => onChange({ ...value, minScore: Number(e.target.value) || 0 })}
        />
      </label>
    </div>
  );
}

function Select({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <label className="flex items-center gap-1.5 text-xs text-text-muted">
      {label}
      <select
        className="input py-1 text-sm"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}

/** Apply filter state to a lead list. */
export function applyFilters<T extends { stage: string; temperature: string; score: number; source: string; createdAt: number; postCreatedAt?: number; name: string; postContent?: string; matchedKeywords: string[]; archived: boolean }>(
  rows: T[],
  f: LeadFilterState,
): T[] {
  const now = Date.now();
  const hours: Record<LeadFilterState["recency"], number> = {
    all: Infinity, "1h": 1, "3h": 3, "6h": 6, "12h": 12, "24h": 24, "7d": 24 * 7,
  };
  const cutoff = now - hours[f.recency] * 3600 * 1000;

  return rows.filter((r) => {
    if (r.archived) return false;
    if (f.stage !== "all" && r.stage !== f.stage) return false;
    if (f.temperature !== "all" && r.temperature !== f.temperature) return false;
    if (f.source !== "all" && r.source !== f.source) return false;
    if (r.score < f.minScore) return false;
    if (f.recency !== "all") {
      const ts = r.postCreatedAt ?? r.createdAt;
      if (ts < cutoff) return false;
    }
    if (f.query) {
      const q = f.query.toLowerCase();
      const hit =
        r.name.toLowerCase().includes(q) ||
        (r.postContent ?? "").toLowerCase().includes(q) ||
        r.matchedKeywords.some((k) => k.toLowerCase().includes(q));
      if (!hit) return false;
    }
    return true;
  });
}
