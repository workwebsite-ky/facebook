import { useEffect, useMemo, useState } from "react";
import { Copy, RefreshCw, Send, Sparkles, Wand2 } from "lucide-react";
import toast from "react-hot-toast";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "@lib/db/schema";
import { logOutreach } from "@lib/db";
import { send } from "../hooks/useRuntime";
import { renderTemplate } from "@lib/utils";
import type { DraftedMessage, Lead, MessageTemplate } from "@types/index";

export function MessageComposer({ lead }: { lead: Lead }) {
  const templates = useLiveQuery<MessageTemplate[]>(() => db.templates.toArray(), [], []);
  const [tone, setTone] = useState<MessageTemplate["tone"]>("friendly");
  const [templateId, setTemplateId] = useState<string>("");
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const [rewriteInstruction, setRewriteInstruction] = useState("");

  // When a template is picked, prefill the body with placeholders substituted.
  useEffect(() => {
    if (!templateId) return;
    const t = templates?.find((x) => x.id === templateId);
    if (!t) return;
    setTone(t.tone);
    setBody(
      renderTemplate(t.body, {
        name: lead.name,
        keyword: lead.matchedKeywords[0] ?? "your project",
        service: lead.matchedKeywords[0] ?? "the help you mentioned",
      }),
    );
  }, [templateId, lead.id]);

  const messengerUrl = useMemo(() => {
    // Open Messenger for a profile — user still has to click send.
    if (!lead.profileUrl) return null;
    return `https://www.facebook.com/messages/t/${encodeURIComponent(lead.profileUrl)}`;
  }, [lead.profileUrl]);

  async function draftWithAi() {
    setBusy(true);
    try {
      const out = await send<DraftedMessage>({
        type: "ai:draftMessage",
        payload: { leadId: lead.id, tone },
      });
      setBody(out.body);
      toast.success("Draft ready");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function rewrite() {
    if (!body.trim() || !rewriteInstruction.trim()) return;
    setBusy(true);
    try {
      const [{ rewriteMessage }, { getSettings }] = await Promise.all([
        import("@lib/api/ai"),
        import("@lib/db"),
      ]);
      const s = await getSettings();
      const out = await rewriteMessage(body, rewriteInstruction, {
        anthropic: s.anthropicApiKey,
        openai: s.openaiApiKey,
      });
      setBody(out);
      toast.success("Rewritten");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function copyAndLog() {
    if (!body.trim()) return;
    await navigator.clipboard.writeText(body);
    await logOutreach({ leadId: lead.id, body, action: "copied", templateId: templateId || undefined });
    toast.success("Copied to clipboard");
  }

  async function openMessengerAndLog() {
    if (!messengerUrl) return;
    await logOutreach({ leadId: lead.id, body, action: "opened_messenger", templateId: templateId || undefined });
    window.open(messengerUrl, "_blank");
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <select
          className="input py-1.5"
          value={templateId}
          onChange={(e) => setTemplateId(e.target.value)}
        >
          <option value="">No template</option>
          {templates?.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
        <select
          className="input py-1.5 w-32"
          value={tone}
          onChange={(e) => setTone(e.target.value as MessageTemplate["tone"])}
        >
          <option value="friendly">Friendly</option>
          <option value="professional">Professional</option>
          <option value="casual">Casual</option>
          <option value="direct">Direct</option>
        </select>
        <button onClick={draftWithAi} disabled={busy} className="btn btn-primary">
          <Sparkles size={14} />
          {busy ? "Drafting…" : "Draft with AI"}
        </button>
      </div>

      <textarea
        className="input min-h-[160px] font-sans leading-relaxed"
        placeholder="Write or generate a message…"
        value={body}
        onChange={(e) => setBody(e.target.value)}
      />

      <div className="flex flex-wrap items-center gap-2">
        <input
          className="input flex-1 min-w-[200px]"
          placeholder="Rewrite instruction (e.g. 'shorter, drop the question')"
          value={rewriteInstruction}
          onChange={(e) => setRewriteInstruction(e.target.value)}
        />
        <button onClick={rewrite} disabled={busy || !body || !rewriteInstruction} className="btn">
          <Wand2 size={14} /> Rewrite
        </button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <button onClick={copyAndLog} disabled={!body.trim()} className="btn">
          <Copy size={14} /> Copy message
        </button>
        <button
          onClick={openMessengerAndLog}
          disabled={!messengerUrl}
          className="btn"
          title={messengerUrl ? "Open Messenger to this profile" : "No profile URL on this lead"}
        >
          <Send size={14} /> Open Messenger
        </button>
        <button onClick={draftWithAi} disabled={busy} className="btn btn-ghost text-text-muted">
          <RefreshCw size={14} /> Regenerate
        </button>
        <span className="text-xs text-text-faint ml-auto">
          {body.trim() ? `${body.trim().split(/\s+/).length} words` : ""}
        </span>
      </div>

      <p className="text-[11px] text-text-faint">
        LeadLoom never sends messages automatically. You always click send inside Messenger.
      </p>
    </div>
  );
}
