import { NavLink } from "react-router-dom";
import {
  BarChart3,
  KeyRound,
  LayoutGrid,
  MessageSquareText,
  Settings as SettingsIcon,
  Users,
} from "lucide-react";
import { cn } from "@lib/utils";

const items = [
  { to: "/leads", label: "Leads", icon: Users },
  { to: "/keywords", label: "Keywords", icon: KeyRound },
  { to: "/templates", label: "Templates", icon: MessageSquareText },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: SettingsIcon },
];

export function Sidebar() {
  return (
    <aside className="w-56 shrink-0 border-r border-border bg-bg-subtle flex flex-col">
      <div className="p-4 flex items-center gap-2 border-b border-border">
        <div className="w-7 h-7 rounded-md bg-accent text-white grid place-items-center text-xs font-bold">
          LL
        </div>
        <div>
          <div className="font-semibold leading-tight">LeadLoom</div>
          <div className="text-[10px] text-text-faint">v0.1.0</div>
        </div>
      </div>

      <nav className="flex-1 p-2 space-y-0.5">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2 px-2.5 py-1.5 rounded-md text-sm",
                isActive ? "bg-bg-hover text-text font-medium" : "text-text-muted hover:bg-bg-hover",
              )
            }
          >
            <Icon size={15} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="p-3 text-[11px] text-text-faint border-t border-border">
        <div className="flex items-center gap-1.5">
          <LayoutGrid size={11} /> ToS-safe build
        </div>
        <p className="mt-1 leading-snug">
          LeadLoom never auto-messages or scrapes Facebook. You always click send.
        </p>
      </div>
    </aside>
  );
}
