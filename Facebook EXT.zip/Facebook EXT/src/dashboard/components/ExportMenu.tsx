import { Download } from "lucide-react";
import { useState } from "react";
import type { Lead } from "@types/index";
import { exportLeadsToCsv, exportLeadsToJson, exportLeadsToXlsx } from "@lib/export";

export function ExportMenu({ rows }: { rows: Lead[] }) {
  const [open, setOpen] = useState(false);
  function run(fn: (l: Lead[]) => void) {
    fn(rows);
    setOpen(false);
  }
  return (
    <div className="relative">
      <button className="btn" onClick={() => setOpen((o) => !o)}>
        <Download size={14} /> Export ({rows.length})
      </button>
      {open && (
        <div
          className="absolute right-0 mt-1 w-40 card p-1 z-10"
          onMouseLeave={() => setOpen(false)}
        >
          <MenuItem onClick={() => run(exportLeadsToCsv)} label="CSV (.csv)" />
          <MenuItem onClick={() => run(exportLeadsToXlsx)} label="Excel (.xlsx)" />
          <MenuItem onClick={() => run(exportLeadsToJson)} label="JSON (.json)" />
        </div>
      )}
    </div>
  );
}

function MenuItem({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left px-2.5 py-1.5 text-sm rounded-md hover:bg-bg-hover"
    >
      {label}
    </button>
  );
}
