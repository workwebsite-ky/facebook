import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Archive, ExternalLink, Trash2, X } from "lucide-react";
import toast from "react-hot-toast";
import { cn, timeAgo } from "@lib/utils";
import { archiveLead, deleteLead, listOutreachForLead, setStage, upsertLead } from "@lib/db";
import { db } from "@lib/db/schema";
import { send } from "../hooks/useRuntime";
import { MessageComposer } from "./MessageComposer";
import type { Lead, LeadStage, OutreachLog } from "@types/index";
import { LEAD_STAGES } from "@types/index";

export function LeadDrawer({
  leadId,
  onClose,
}: {
  leadId: string | null;
  onClose: () => void;
}) {
  const lead = useLiveQuery(() => (leadId ? db.leads.get(leadId) : undefined), [leadId], undefined);
  const [outreach, setOutreach] = useState<OutreachLog[]>([]);

  useEffect(() => {
    if (!leadId) return;
    listOutreachForLead(leadId).then(setOutreach);
  }, [leadId, lead?.updatedAt]);

  if (!leadId) return null;

  return (
    <aside className="fixed top-0 right-0 h-full w-[520px] max-w-[90vw] bg-bg border-l border-border shadow-drawer flex flex-col z-40">
      <header className="flex items-center justify-between px-5 py-3 border-b border-border">
        <div className="min-w-0">
          <div className="font-semibold truncate">{lead?.name ?? "—"}</div>
          <div className="text-xs text-text-faint">
            {lead?.source} • captured {lead ? timeAgo(lead.createdAt) : ""}
          </div>
        </div>
        <button onClick={onClose} className="btn btn-ghost p-1.5">
          <X size={16} />
        </button>
      </header>

      {!lead ? (
        <div className="p-10 text-center text-text-muted">Lead not found.</div>
      ) : (
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          <StagePicker
            current={lead.stage}
            onChange={(s) => setStage(lead.id, s).then(() => toast.success(`Moved to ${s}`))}
          />

          {lead.postContent && (
            <section>
              <H3>Original post / message</H3>
              <div className="card p-3 text-sm whitespace-pre-wrap text-text-muted">{lead.postContent}</div>
              {lead.postUrl && (
                <a
                  href={lead.postUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-accent hover:underline mt-1.5"
                >
                  Open on Facebook <ExternalLink size={12} />
                </a>
              )}
            </section>
          )}

          <section>
            <H3>AI compose</H3>
            <MessageComposer lead={lead} />
          </section>

          <section>
            <H3>Notes</H3>
            <textarea
              className="input min-h-[80px]"
              defaultValue={lead.notes ?? ""}
              placeholder="Anything you want to remember about this lead…"
              onBlur={(e) =>
                upsertLead({ ...lead, notes: e.target.value }).then(() => toast.success("Notes saved"))
              }
            />
          </section>

          <section>
            <H3>History</H3>
            {outreach.length === 0 ? (
              <p className="text-sm text-text-faint">No outreach logged yet.</p>
            ) : (
              <ul className="space-y-2">
                {outreach.map((o) => (
                  <li key={o.id} className="card p-3 text-sm">
                    <div className="flex items-center justify-between text-xs text-text-faint">
                      <span className="capitalize">{o.action.replace("_", " ")}</span>
                      <span>{timeAgo(o.createdAt)}</span>
                    </div>
                    <p className="mt-1 text-text-muted whitespace-pre-wrap">{o.body}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <footer className="flex items-center gap-2 pt-4 border-t border-border">
            <button
              onClick={() => archiveLead(lead.id, true).then(onClose)}
              className="btn"
            >
              <Archive size={14} /> Archive
            </button>
            <button
              onClick={() => {
                if (confirm("Delete this lead permanently?")) deleteLead(lead.id).then(onClose);
              }}
              className="btn text-rose-600"
            >
              <Trash2 size={14} /> Delete
            </button>
            <button
              onClick={async () => {
                await send({ type: "lead:score", payload: { leadId: lead.id } });
                toast.success("Re-scored");
              }}
              className="btn ml-auto"
            >
              Re-score with AI
            </button>
          </footer>
        </div>
      )}
    </aside>
  );
}

function StagePicker({ current, onChange }: { current: LeadStage; onChange: (s: LeadStage) => void }) {
  return (
    <div className="flex flex-wrap gap-1">
      {LEAD_STAGES.map((s) => (
        <button
          key={s}
          onClick={() => onChange(s)}
          className={cn(
            "pill px-2.5 py-1 border",
            current === s
              ? "bg-accent text-white border-transparent"
              : "border-border text-text-muted hover:bg-bg-hover",
          )}
        >
          {s.replace("_", " ")}
        </button>
      ))}
    </div>
  );
}

function H3({ children }: { children: React.ReactNode }) {
  return <h3 className="text-xs uppercase tracking-wide text-text-faint mb-2">{children}</h3>;
}
