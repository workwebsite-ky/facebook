/**
 * Core type definitions for LeadLoom.
 *
 * Naming convention:
 *  - All persisted entities have an `id` (uuid v4) and `createdAt` / `updatedAt` epoch ms.
 *  - Enums are encoded as string literal unions for IndexedDB friendliness.
 */

export type ID = string;
export type EpochMs = number;

// ---------------------------------------------------------------------------
// Lead
// ---------------------------------------------------------------------------

/** Stage of the sales pipeline. Ordered from earliest to latest. */
export const LEAD_STAGES = [
  "new",
  "contacted",
  "replied",
  "interested",
  "closed_won",
  "closed_lost",
] as const;
export type LeadStage = (typeof LEAD_STAGES)[number];

/** AI/heuristic-assigned temperature label. */
export type LeadTemperature = "hot" | "warm" | "cold";

/** Where this lead originally entered the CRM. */
export type LeadSource =
  | "lead_ads" // pulled via Meta Lead Ads API
  | "page_mention" // user's Page was tagged/mentioned
  | "manual_save" // user clicked "Save as Lead" on a public post they were viewing
  | "csv_import" // bulk CSV/Excel import
  | "manual_entry"; // typed in by hand

export interface Lead {
  id: ID;
  /** Display name. */
  name: string;
  /** Public Facebook profile/page URL if available. */
  profileUrl?: string;
  /** Country / locale guess (ISO-3166 alpha-2 if known). */
  country?: string;
  language?: string;

  /** The post content / form responses / inbound message that created this lead. */
  postContent?: string;
  /** When the originating post/message was published. */
  postCreatedAt?: EpochMs;
  /** URL back to the post if known. */
  postUrl?: string;
  /** Group name if the post was in a group. */
  groupName?: string;

  /** Keyword(s) that matched this lead. */
  matchedKeywords: string[];

  /** Engagement signals from the originating post, if known. */
  engagement?: {
    likes?: number;
    comments?: number;
    shares?: number;
  };

  /** Pipeline stage. */
  stage: LeadStage;
  /** AI-assigned temperature. */
  temperature: LeadTemperature;
  /** 0–100 numeric score (higher = more promising). */
  score: number;

  /** Where this lead came from. */
  source: LeadSource;
  /** Free-form notes by the user. */
  notes?: string;
  /** Free-form tags. */
  tags: string[];

  /** Follow-up reminder (epoch ms). null = no reminder. */
  followUpAt?: EpochMs;

  /** Flagged as spam / hidden from main view. */
  archived: boolean;

  createdAt: EpochMs;
  updatedAt: EpochMs;
}

// ---------------------------------------------------------------------------
// Keyword & search
// ---------------------------------------------------------------------------

export interface Keyword {
  id: ID;
  /** Phrase the user wants to track. */
  phrase: string;
  /** Optional language filter. */
  language?: string;
  /** Optional country filter. */
  country?: string;
  /** Whether monitoring this keyword is active. */
  active: boolean;
  /** Last time we surfaced/checked this keyword. */
  lastUsedAt?: EpochMs;
  createdAt: EpochMs;
}

// ---------------------------------------------------------------------------
// Message templates & outbox
// ---------------------------------------------------------------------------

export interface MessageTemplate {
  id: ID;
  name: string;
  /** Mustache-like placeholders: {{name}}, {{keyword}}, {{service}} etc. */
  body: string;
  /** Tags for filtering (e.g. "logo", "web", "follow-up"). */
  tags: string[];
  /** Casual / professional / friendly / direct. */
  tone: "casual" | "professional" | "friendly" | "direct";
  createdAt: EpochMs;
  updatedAt: EpochMs;
}

/**
 * Record of an outreach attempt. LeadLoom never sends messages
 * automatically — this only logs what the user copied / opened.
 */
export interface OutreachLog {
  id: ID;
  leadId: ID;
  templateId?: ID;
  body: string;
  /** What the user actually did. */
  action: "copied" | "opened_messenger" | "sent_manually" | "drafted";
  createdAt: EpochMs;
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

export interface Settings {
  /** Singleton row — always id = "default". */
  id: "default";

  /** Anthropic API key (stored in chrome.storage.local, encrypted at rest). */
  anthropicApiKey?: string;
  /** OpenAI fallback (optional). */
  openaiApiKey?: string;

  /** Meta long-lived user/page access token for Lead Ads. */
  metaAccessToken?: string;
  /** Selected Page IDs to sync leads from. */
  metaPageIds: string[];

  /** UI prefs. */
  theme: "light" | "dark" | "system";
  density: "comfortable" | "compact";

  /** Default tone for AI message generation. */
  defaultTone: MessageTemplate["tone"];

  /** Minimum score to surface a lead by default. */
  minScoreFilter: number;

  /** How often to poll Meta APIs (minutes). */
  syncIntervalMinutes: number;

  /** Whether to show desktop notifications for hot leads. */
  notifyOnHot: boolean;

  updatedAt: EpochMs;
}

// ---------------------------------------------------------------------------
// AI types
// ---------------------------------------------------------------------------

export interface IntentAnalysis {
  temperature: LeadTemperature;
  score: number; // 0–100
  /** Detected service category (e.g. "logo", "website"). */
  category?: string;
  /** Detected urgency words. */
  urgencyMarkers: string[];
  /** Brief one-line rationale. */
  rationale: string;
  /** "ai" if Claude scored it, "heuristic" if local rules. */
  method: "ai" | "heuristic";
}

export interface DraftedMessage {
  body: string;
  /** Estimated reading time / sentiment / etc. for UI display. */
  meta?: {
    tone: MessageTemplate["tone"];
    wordCount: number;
  };
}

// ---------------------------------------------------------------------------
// Messaging between extension surfaces
// ---------------------------------------------------------------------------

/** Discriminated union for chrome.runtime.sendMessage payloads. */
export type RuntimeMessage =
  | { type: "lead:save"; payload: Partial<Lead> & { name: string } }
  | { type: "lead:score"; payload: { leadId: ID } }
  | { type: "lead:list"; payload?: { stage?: LeadStage } }
  | { type: "settings:get" }
  | { type: "settings:update"; payload: Partial<Settings> }
  | { type: "sync:metaLeadAds" }
  | { type: "ai:draftMessage"; payload: { leadId: ID; templateId?: ID; tone?: MessageTemplate["tone"] } }
  | { type: "ai:scoreText"; payload: { text: string } };

export interface RuntimeResponse<T = unknown> {
  ok: boolean;
  data?: T;
  error?: string;
}
