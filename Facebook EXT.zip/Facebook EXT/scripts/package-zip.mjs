#!/usr/bin/env node
/**
 * Package the built extension into a zip for upload to the Chrome Web Store
 * or for internal distribution. Run `npm run build` first.
 */

import { createWriteStream, existsSync, mkdirSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { Buffer } from "node:buffer";
import { fileURLToPath } from "node:url";
import { dirname } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = join(__dirname, "..");
const dist = join(root, "dist");
const out = join(root, "dist-zip");

if (!existsSync(dist)) {
  console.error("dist/ not found. Run `npm run build` first.");
  process.exit(1);
}
if (!existsSync(out)) mkdirSync(out, { recursive: true });

const pkg = JSON.parse(await (await import("node:fs/promises")).readFile(join(root, "package.json"), "utf8"));
const zipPath = join(out, `leadloom-${pkg.version}.zip`);

// Minimal zip writer (store-only, no deps). For real distribution use
// archiver or bestzip — this just gets the job done with zero deps.
const { default: archiver } = await import("archiver").catch(() => ({ default: null }));
if (!archiver) {
  console.error("Install `archiver` (npm i -D archiver) to use this script, or zip the dist/ folder manually.");
  process.exit(1);
}

const output = createWriteStream(zipPath);
const archive = archiver("zip", { zlib: { level: 9 } });
output.on("close", () => console.log(`Packaged: ${relative(root, zipPath)} (${archive.pointer()} bytes)`));
archive.on("error", (err) => { throw err; });
archive.pipe(output);
archive.directory(dist, false);
await archive.finalize();
